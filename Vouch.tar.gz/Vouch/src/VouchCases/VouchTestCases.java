package VouchCases;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Driver;
import java.util.Properties;
import java.util.concurrent.ForkJoinPool.ManagedBlocker;
import java.util.concurrent.TimeUnit;
import VouchOperation.VouchReadObject;
import VouchOperation.VouchUIoperation;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import VouchExcelFile.VouchExcelReadWrite;
public class VouchTestCases {
	
	WebDriver webdriver = null;
    @Test(dataProvider="hybridData")
	public void Testlogin(String TestCase,String Keyword,String ObjectName,String ObjectType,String value) throws Exception {
		// TODO Auto-generated method stub
      
    	
    	if(TestCase!=null&&TestCase.length()!=0){
    		System.setProperty("webdriver.gecko.driver","/home/vikas/Vikas/Vikas/Selenium/geckodriver");
    	webdriver=new FirefoxDriver();
    	
    	   	 
    	}
        VouchReadObject object = new VouchReadObject();
        Properties allObjects =  object.getObjectRepository();
        VouchUIoperation operation = new VouchUIoperation(webdriver);
      	//Call perform function to perform operation on UI
    			operation.perform(allObjects, Keyword, ObjectName,
    				ObjectType, value);
    	    
	}

    
    @DataProvider(name="hybridData")
	public Object[][] getDataFromDataprovider() throws IOException{
    	Object[][] object = null; 
    	VouchExcelReadWrite file = new VouchExcelReadWrite();
        
         //Read keyword sheet
         Sheet vouchSheet = file.readExcel("/home/vikas", "Vouch.xlsx", "vouchcase");
         System.out.println("Current working directory : " + vouchSheet);
       //Find number of rows in excel file
         
        // Row rowToWrite = vouchSheet.getRow(0);
         
         
      //  Cell cellToWrite =	rowToWrite.getCell(5);
         
       // cellToWrite.setCellValue("pass");
         
     	int rowCount = vouchSheet.getLastRowNum()-vouchSheet.getFirstRowNum();
     	
     	object = new Object[rowCount][5];
     	for (int i = 0; i < rowCount; i++) {
    		//Loop over all the rows
     		
     		Row row = vouchSheet.getRow(i+1);
     		// cell1.setCellType(Cell.CELL_TYPE_STRING);
     		
     	
    		//Create a loop to print cell values in a row
    	for (int j = 0; j < row.getLastCellNum(); j++) {
    			//Print excel data in console
    			Cell currentCell = row.getCell(j);
    			if (currentCell.getCellTypeEnum() == CellType.NUMERIC ) {
    			int intValue  = (int) row.getCell(j).getNumericCellValue();
    			
    			object[i][j] = intValue + "";
    			} else if (currentCell.getCellTypeEnum() == CellType.STRING ) {
    				String stringValue  = row.getCell(j).getStringCellValue();
        			
        			object[i][j] = stringValue;
        			        			
    	   		}  
    	    			
    		}
  	
    		
     	}
     
     	System.out.println("");
     	  return object;	 
    }
     	  

//Method 2
    @Test(dataProvider="hybridData1")
    public void AddVoucher(String TestCase,String Keyword,String ObjectName,String ObjectType,String value) throws Exception {
		// TODO Auto-generated method stub
      
    	
    	if(TestCase!=null&&TestCase.length()!=0){
    		System.setProperty("webdriver.gecko.driver","/home/vikas/Vikas/Vikas/Selenium/geckodriver");
    	webdriver=new FirefoxDriver();
    	
    	   	 
    	}
        VouchReadObject object = new VouchReadObject();
        Properties allObjects =  object.getObjectRepository();
        VouchUIoperation operation = new VouchUIoperation(webdriver);
      	//Call perform function to perform operation on UI
    			operation.perform(allObjects, Keyword, ObjectName,
    				ObjectType, value);
    	    
	}
    
    
    @DataProvider(name="hybridData1")
	public Object[][] getDataFromDataprovider1() throws IOException{
    	Object[][] object = null; 
    	VouchExcelReadWrite file = new VouchExcelReadWrite();
        
         //Read keyword sheet
         Sheet vouchSheet = file.readExcel("/home/vikas", "Vouch.xlsx", "vouchcase");
         System.out.println("Current working directory : " + vouchSheet);
       //Find number of rows in excel file
         
        // Row rowToWrite = vouchSheet.getRow(0);
         
         
      //  Cell cellToWrite =	rowToWrite.getCell(5);
         
       // cellToWrite.setCellValue("pass");
         
     	int rowCount = vouchSheet.getLastRowNum()-vouchSheet.getFirstRowNum();
     	
     	object = new Object[rowCount][5];
     	for (int i = 0; i < rowCount; i++) {
    		//Loop over all the rows
     		
     		Row row = vouchSheet.getRow(i+1);
     		// cell1.setCellType(Cell.CELL_TYPE_STRING);
     		
     	
    		//Create a loop to print cell values in a row
   	for (int j = 0; j < row.getLastCellNum(); j++) {
    			//Print excel data in console
    			Cell currentCell = row.getCell(j);
    			if (currentCell.getCellTypeEnum() == CellType.NUMERIC ) {
    			int intValue  = (int) row.getCell(j).getNumericCellValue();
    			
    			object[i][j] = intValue + "";
    			} else if (currentCell.getCellTypeEnum() == CellType.STRING ) {
    				String stringValue  = row.getCell(j).getStringCellValue();
        			
        			object[i][j] = stringValue;
        			        			
    	   		}  
    	    			
    		}
    		
    	    
     	System.out.println("");
     	  return object;	 
     	}
		return object;
     	  
    }

     	
     	
}




