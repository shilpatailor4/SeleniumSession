package VouchOperation;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import org.apache.poi.hpsf.Property;

public class VouchReadObject {

	Properties p = new Properties();
	 
	public Properties getObjectRepository() throws IOException{
		//Read object repository file
		InputStream stream = new FileInputStream(new File("/home/vikas/eclipse-workspace/Vouch/src/Object/Vouchobject.properties"));
		//load all objects
		p.load(stream);
		 return p;
		
	}

	}
