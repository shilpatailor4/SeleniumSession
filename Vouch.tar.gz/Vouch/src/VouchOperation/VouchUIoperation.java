package VouchOperation;

import java.sql.Driver;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class VouchUIoperation {
	
	WebDriver driver;
	private WebElement WebElement;
	public VouchUIoperation(WebDriver driver) {
		// TODO Auto-generated constructor stub
	
		this.driver = driver;
	}
	public void perform(Properties p,String operation,String objectName,String objectType,String value) throws Exception{
		System.out.println("");
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		switch (operation.toUpperCase()) {
				case "CLICK": 
			//Perform click
			driver.findElement(this.getObject(p,objectName,objectType)).click();
			
			break;
		case "SETTXT":
			//Set text on control
			driver.findElement(this.getObject(p,objectName,objectType)).sendKeys(value);
			break;
			
		case "GOTOURL":
			//Get url of application
			driver.get(p.getProperty(value));
			break;
			
		case "GOTOURL1":
			//Get url of application
			driver.get(p.getProperty(value));
			break;
			
		case "UPLOADED": 
			Thread.sleep(5000);
			driver.findElement(this.getObject(p,objectName,objectType)).sendKeys(value);
			Thread.sleep(5000);
			break;
			
			
		 case "DROP":
			
			
		Select oselect =  new Select(driver.findElement(this.getObject(p, objectName, objectType)));
		    
			oselect.selectByVisibleText(value);
			Thread.sleep(5000);
			break;
		
					
			//driver.findElement(this.getObject(p,objectName,objectType)).isSelected();
			
			
		//case "CLICK1":
			//driver.findElement(this.getObject(p,objectName,objectType)).click();
			//break;
			//Get text of an element
			//Actions action = new Actions(driver);
    		//WebElement we = driver.findElement(this.getObject(p,objectName,objectType));
			//driver.findElement(this.getObject(p,objectName,objectType)).click();
    		//we.click();
    		//action.moveToElement(we).build().perform();
			//driver.findElement(this.getObject(p,objectName,objectType)).getText();
			//break;

		default:
			break;
		}
	}
	
	/**
	 * Find element BY using object type and value
	 * @param p
	 * @param objectName
	 * @param objectType
	 * @return
	 * @throws Exception
	 */
	private By getObject(Properties p,String objectName,String objectType) throws Exception{
		
		
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		//Find by xpath
		if(objectType.equalsIgnoreCase("XPATH")){
			
			return By.xpath(p.getProperty(objectName));
		}
		//find by id
		else if(objectType.equalsIgnoreCase("ID")){
			
			return By.id(p.getProperty(objectName));
		}
		//find by class
		else if(objectType.equalsIgnoreCase("CLASSNAME")){
			
			return By.className(p.getProperty(objectName));
			
		}
		//find by name
		else if(objectType.equalsIgnoreCase("NAME")){
			
			return By.name(p.getProperty(objectName));
			
		}
		//Find by css
		else if(objectType.equalsIgnoreCase("CSS")){
			
			return By.cssSelector(p.getProperty(objectName));
			
		}
		//find by link
		else if(objectType.equalsIgnoreCase("LINK")){
			
			return By.linkText(p.getProperty(objectName));
			
		}
		//find by partial link
		else if(objectType.equalsIgnoreCase("PARTIALLINK")){
			
			return By.partialLinkText(p.getProperty(objectName));
			
					
		}else
		{
			throw new Exception("Wrong object type");
		}
		}
	}


