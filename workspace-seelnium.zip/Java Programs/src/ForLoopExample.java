
public class ForLoopExample {

	public static void main(String[] args) {
		
          
		for(int i=10; i>1; i--) {
			
			System.out.println("A value of i is: " +i);
		}
	}

}
