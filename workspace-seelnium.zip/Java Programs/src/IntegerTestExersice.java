
public class IntegerTestExersice {

	public static void main(String[] args) {
		
		int carSpeed;
		
		carSpeed = 20;
		
		System.out.println("The running speed of car is: " + carSpeed);
		
		carSpeed = carSpeed + 20;
		
		System.out.println("The current speed of car is: " + carSpeed);
	}

}
