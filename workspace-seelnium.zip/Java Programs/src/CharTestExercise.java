
public class CharTestExercise {

	public static void main(String[] args) {
		
		char a;
		
		a = 'P';
		
		System.out.println("Value of char is: " + a);
		

	}

}
