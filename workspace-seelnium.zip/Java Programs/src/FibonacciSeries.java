
public class FibonacciSeries {

	public static void main(String[] args) {
		
		int count = 7, num1 = 0, num2 = 1;
		System.out.println("Number: "+count+" number");
		
		for(int i=0; i<count; i++) {
			
			System.out.println(num1);
		
		
		int SumOfPrevTwo = num1 + num2;
		
		num1 = num2;
		
		num2 = SumOfPrevTwo;
		
		}
		

	}

}
