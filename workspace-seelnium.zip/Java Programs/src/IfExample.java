
public class IfExample {

	public static void main(String[] args) {
		
		//..........If example................
		
	/*int age = 20;
		
	
		if(age>18) {
			
			System.out.println("Age is greater than 18");
		}  */
		
		
	//...............If-else....................	
		
	int number = 13;
		
		if(number%2==0) {
			
			System.out.println("Even number");
		}else {
			
			System.out.println("Odd number");
		}

     }
		
}
