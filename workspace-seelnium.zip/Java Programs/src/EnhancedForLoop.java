
public class EnhancedForLoop {

	public static void main(String[] args) {
		
		int[] number = {3, 4, 5, -5, 0, 12};
		int sum=0;
		
		for(int number1: number) {
			
			sum += number1;
			
		}
			
			System.out.println("Sum: " +sum);
		

	}

}
