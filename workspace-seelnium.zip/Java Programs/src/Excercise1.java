
public class Excercise1 {

	public static void main(String[] args) {
		
		//.......Print values.................
		
		System.out.println("++++++");
		
		System.out.println("@@@@@@");
		
		System.out.println("******");
		
		System.out.println("######");
		System.out.println("   ");
		
		//..........................declare three variable......
		
    	int a;
		double b;
		double c;
		
		a = 10;
		b = 20.3;
	    c = 3.14785;
		
		
		System.out.println("The integer value is: " + a);
		
		System.out.println("The floting value is: " + b);
		
		System.out.println("The floting value is: " + c);
		System.out.println("   ");
		
		//..........declare a Boolean variable ...........................
		
		boolean value = true;
		
		value = false;
		
		System.out.println("The value is: " + value);
		
		
		
	}

}
