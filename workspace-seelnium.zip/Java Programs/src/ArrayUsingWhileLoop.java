
public class ArrayUsingWhileLoop {

	public static void main(String[] args) {
		
		int arr[] = {2, 11, 45, 9};
		int i = 0;
		
		while(i<3) {
			
			System.out.println(arr[i]);
			i++;
		}

	}

}
