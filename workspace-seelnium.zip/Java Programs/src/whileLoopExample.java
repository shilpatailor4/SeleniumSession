
public class whileLoopExample {

	public static void main(String[] args) {
		

		int i=10;
		
		while(i>=1) {
			
			System.out.println("Line: " +i);
			i--;
		}

	}

}
