
public class ForLoopArray {

	public static void main(String[] args) {
		
		char[] vowels = {'a', 'e', 'i', 'o', 'u'};
		
		
		
	/*	for(int i =0; i < vowels.length; ++i) {
			
			System.out.println(vowels[i]);
		}
   */
		//for each loop
		for (char item: vowels) {
	         System.out.println(item);
	      }
		
	}

}
