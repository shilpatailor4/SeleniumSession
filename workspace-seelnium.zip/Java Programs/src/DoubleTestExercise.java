
public class DoubleTestExercise {

	public static void main(String[] args) {
		
		double PI;
		
		PI = 3.1234;
		
		System.out.println("PI: " + PI);

	}

}
