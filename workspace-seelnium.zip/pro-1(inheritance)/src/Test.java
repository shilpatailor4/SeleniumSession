
public class Test {
	public static void main(String[] args) {
		//Employee e=new Employee();
		Developer d=new Developer();
		d.salary=10000;
		Sale s=new Sale();
		s.salary=10000;
		s.calSal();
		d.calSal();
	}

}
