
public abstract class Employee {
	
	int id;
	String name;
	float salary;
	public void demo() {
		System.out.println("parent");
	}
	
	public abstract void calSal();//abstract method should be implement in chiled 
	
}

class Developer extends Employee{
	
	int profile;
	
	public void calSal() {
		
		salary=salary+1000+800;
		System.out.println("salary of developer ="+salary);
	}
	
}
class Sale extends Employee{
	
public void calSal() {
		
		salary=salary+1000+800+600;
		System.out.println("salary of sales ="+salary);
	}
}