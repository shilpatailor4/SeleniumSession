package selenium_pkg;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class URL_run {
	
	public static void main(String arg[]) throws InterruptedException{
		
		System.setProperty("webdriver.gecko.driver", "/home/shilpatailor/selenium/geckodriver");
		
		WebDriver driver = new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		Thread.sleep(5000);
		
		//driver.get("https://www.google.com/");
		
		/*String url = "https://demo.guru99.com/test/newtours";*/
		String expectedTitle = "Welcome: Mercury Tours";
		String actualTitle = "";
		
		driver.get("https://demo.guru99.com/test/newtours");
		actualTitle = driver.getTitle();
		
		if(actualTitle.contentEquals(expectedTitle)){
			
			System.out.println("passed");
			
		}else{
			
			System.out.println("failed");
		}
		
		driver.close();
		
		
	}

}
