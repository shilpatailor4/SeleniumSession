package selenium_pkg;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class google_run {

	public static void main(String arg[]) throws InterruptedException {
		
		System.setProperty("webdriver.gecko.driver", "/home/shilpatailor/selenium/geckodriver");
		
		WebDriver driver = new FirefoxDriver();
		
		Thread.sleep(5000);
		
		driver.get("https://www.guru99.com");
		
		driver.close();
		
	}
}
