package selenium_pkg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class gmail_login {
	
	public static void main(String[] arg) throws InterruptedException {
		
		System.setProperty("webdriver.gecko.driver", "/home/shilpatailor/selenium/geckodriver");
		
		WebDriver driver = new FirefoxDriver();
		
		Thread.sleep(5000);
		
		driver.get("https://accounts.google.com/signin");
		
		Thread.sleep(5000);

		
		/*WebElement e =driver.findElement(By.xpath("/html/body/div[2]/div[1]/div[5]/ul[1]/li[2]/a"));
		e.click();
		Thread.sleep(5000);*/
		
		
		WebElement email = driver.findElement(By.xpath("//*[@id=\"identifierId\"]"));
		Thread.sleep(5000);
		/*String edit_email = email.getText();
		System.out.println(edit_email);
		
		Thread.sleep(3000);*/
		
				email.sendKeys(new String[] {"testxyz231"});
				
		driver.findElement(By.xpath("//*[@id=\"identifierNext\"]/content/span")).click();
		
		Thread.sleep(3000);
				

		WebElement pass = driver.findElement(By.name("password"));
		/*String edit_pass = pass.getText();
		System.out.println(edit_pass);*/  //check the validation message
		
		
		
				pass.sendKeys(new String[] {"shilpa@123"});
				
				Thread.sleep(2000);
				
				driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[2]/div[2]/div/div/div[2]/div/div[2]/div/div[1]/div/content")).click();
	
				
				Thread.sleep(5000);
	
				System.out.println("Successfully login");
		
		
		
		
		
	driver.close();
		
	}

}
