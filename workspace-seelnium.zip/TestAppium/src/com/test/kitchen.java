package com.test;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class kitchen {


static AppiumDriver<MobileElement> driver = null;
public static MobileElement mobileElement;
public static void main(String[] args) throws InterruptedException {

DesiredCapabilities caps = new DesiredCapabilities();
caps.setCapability("deviceName", "My Phone");
caps.setCapability("udid", "e5696a1a0703");
caps.setCapability("platformName", "Android");
caps.setCapability("platformVersion", "7.0");
caps.setCapability("appPackage", "kichenmanager.sitsl");
caps.setCapability("appActivity", "kichenmanager.sitsl.activity.SplashScreen"); // cd downloads. where apk is present. give this command in terminal. aapt dump badging ./Downloads/kitchen_manager.apk
caps.setCapability("noReset", "true"); //Command to get App activity: aapt dump badging ./Downloads/kitchen_manager.apk

//Instantiate Appium Driver
try {
driver = new AndroidDriver<MobileElement>(new URL("http://127.0.0.1:4723/wd/hub"), caps);

} catch (MalformedURLException e) {
System.out.println(e.getMessage());

}
Thread.sleep(5000);
if (driver!=null)
{
System.out.println("Driver is not null");
//driver.findElementById("kichenmanager.sitsl:id/imageViewMenu").click();
driver.findElementById("kichenmanager.sitsl:id/edtUsername").clear();
driver.findElementById("kichenmanager.sitsl:id/edtUsername").sendKeys("admin@gmail.com");
driver.findElementById("kichenmanager.sitsl:id/edtPassword").clear();
driver.findElementById("kichenmanager.sitsl:id/edtPassword").sendKeys("123456");
driver.findElementById("kichenmanager.sitsl:id/activity_login").click();

System.out.println("The application successfully login");

//driver.findElementById("kichenmanager.sitsl:id/imageViewMenu").click();

driver.findElementByName("Log Out").click();

}

//driver.findElementById("kichenmanager.sitsl:id/tv_title").click();
//driver.findElementById("kichenmanager.sitsl:id/imageViewEditIcon").click();


}
}
