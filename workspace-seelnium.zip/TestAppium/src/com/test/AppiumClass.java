package com.test;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;

import org.omg.CORBA.Environment;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class AppiumClass {
	//private static WebDriver driver = null;
	public static void main(String[] args) {
		
		
		
		//Set the Desired Capabilities
		DesiredCapabilities caps = new DesiredCapabilities();
		caps.setCapability("deviceName", "My Phone");
		caps.setCapability("udid", "e5696a1a0703"); //Give Device ID of your mobile phone
		caps.setCapability("platformName", "Android");
		caps.setCapability("platformVersion", "7.0");
		caps.setCapability("appPackage", "com.theshaadi");
		caps.setCapability("appActivity", "com.theshaadi.splash.SplashActivity");    // App Activity of Shaadi App  com.theshaadi.splash.SplashActivity
		caps.setCapability("noReset", "true");                                             //Command to get App activity: aapt dump badging ./Downloads/kitchen_manager.apk
		
	
		
		
		//Instantiate Appium Driver
		try {
			
			
				AppiumDriver<MobileElement> driver = new AndroidDriver<MobileElement>(new URL("http://127.0.0.1:4723/wd/hub"), caps);
				WebElement button= driver.findElement(By.name(""));
		} catch (MalformedURLException e) {
			System.out.println(e.getMessage());
		}
		
		
		
		
	}
	
	
}
