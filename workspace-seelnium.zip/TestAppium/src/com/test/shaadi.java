package com.test;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriver.Timeouts;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class shaadi {
		
	private static AppiumDriver driver;
	public static MobileElement mobileElement;
		
	public static void main(String[] args) throws InterruptedException, MalformedURLException {

		

		
		
		
			
			//Set the Desired Capabilities
			DesiredCapabilities caps = new DesiredCapabilities();
			caps.setCapability("deviceName", "");
			caps.setCapability("udid", "ZY223ZGH5D"); //Give Device ID of your mobile phone
			caps.setCapability("platformName", "Android");
			caps.setCapability("platformVersion", "7.0");
			caps.setCapability("appPackage", "com.theshaadi");
			caps.setCapability("appActivity", "com.theshaadi.splash.SplashActivity");    // App Activity of Shaadi App  com.theshaadi.splash.SplashActivity
			caps.setCapability("noReset", "true");  
	//		caps.setCapability("AutomationName", "Selendroid");
			
		//	com.theshaadi.login.LoginActivity
			
			
			//Instantiate Appium Driver
			try {
  				driver = new AndroidDriver<MobileElement>(new URL("http://127.0.0.1:4723/wd/hub"), caps);
  				//driver.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
  				
  		} catch (MalformedURLException e) {
  			System.out.println(e.getMessage());
  		}
	
	        Thread.sleep(5000);
	          
	              
		              Thread.sleep(10000);
		              
		             
		              System.out.println("Before");
		              ((MobileElement) driver.findElementById("com.theshaadi:id/edtTxtUserName")).setValue("1600");
		          //    WebElement addContactButton = driver.findElement(By.name("Mobile No."));
		          //    addContactButton.sendKeys("8619592802");
		
		              
		              System.out.println("After");
		              
		    
	             
	}	    
	}

