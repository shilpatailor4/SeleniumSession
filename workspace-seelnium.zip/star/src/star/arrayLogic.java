package star;

public class arrayLogic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a[] = new int[5]; //dynamic insliazation
		int b[] = new int[] {10, 30, 45, 27, 28}; // static insliazation
		
		for(int i=0; i<5; i++) {
			
			System.out.println(b[i]);
		}

	}

}
