package star;

public class MaxvalueFromArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a[] = new int[] {10, 20, 30, 80, 40, 50};
		
		int tempValue = 0;
		
		for(int i=0; i< a.length; i++) {
			if(tempValue < a[i]) {
				tempValue = a[i];
				
			}
		}

		System.out.println(tempValue);
	}

}
