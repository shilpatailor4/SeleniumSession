package star;

public class starPrint {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int i,j, k;
		
		for(i=1;i<=6; i++) {
			for(k=1; k<=6-i; k++) {
				System.out.print(" ");
			}
			for(j=1; j<i; j++) {
				System.out.printf("* ");
			}
			System.out.println();
			
		}
	}
	}


