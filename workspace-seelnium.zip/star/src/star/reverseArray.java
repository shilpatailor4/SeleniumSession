package star;

public class reverseArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int temp = 0;
	int a[] = new int[] {10,20,30,40,50};
		for(int i=0; i<5/2; i++) {
			temp = a[i];
			a[i] = a[4-i];
			a[4-i] = temp;
			
			
		}
		
		for(int o:a) {
			System.out.println(o);
		}
		
	}

}
