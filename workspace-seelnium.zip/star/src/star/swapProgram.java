package star;

public class swapProgram {
	
	public static void main(String arg[]) {
		
		int a = 5, b = 7;
		
		a = a+b;
		b = a-b;
		a = a-b;
		
		System.out.println("a = " +a + " b =" + b);
		
	}

}
