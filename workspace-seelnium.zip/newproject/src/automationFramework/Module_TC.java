package automationFramework;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import appModule.SignIn_Action;
import pageObjects.Home_Page;

public class Module_TC {
	
	private static final String String = null;
	private static WebDriver driver = null;

	public static void main(String[] args) throws Exception {
		
		System.setProperty("webdriver.gecko.driver", "/home/shilpatailor/Driver/geckodriver");

		WebDriver driver = new FirefoxDriver();
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		driver.get("http://www.store.demoqa.com");
		
		 // Use your Module SignIn now
		SignIn_Action.Execute(driver);
		
		// Take screenshot and store as a file format
		File src= ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		
		 // now copy the  screenshot to desired location using copyFile //method
		FileUtils.copyFile(src, new File("/home/shilpatailor/workspace/newproject/src/screenshot/login.png"));
	
		
		System.out.println("Login Successfully, now it is the time to Log Off buddy.");
		
		Thread.sleep(5000);
		
		// Take screenshot and store as a file format
			File src1= ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
				
		// now copy the  screenshot to desired location using copyFile //method
			try {
			FileUtils.copyFile(src1, new File("/home/shilpatailor/workspace/newproject/src/screenshot/home.png"));
			}
			
			catch (IOException e)
			 {
			  System.out.println(e.getMessage());
			 
			 }
		Home_Page.lnk_LogOut(driver).click();
			
		driver.close();
		
		
		

	}

}
