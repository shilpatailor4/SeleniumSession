package automationFramework;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import appModule.SignIn_Action;
import pageObjects.Home_Page;
import pageObjects.LogIn_Page;

// Import package utility.*

import utility.Constant;
import utility.ExcelUtils;

public class Global_Var_TC {
	
	private static WebDriver driver = null;
	
	public static void main(String[] args) throws Exception {
		
		System.setProperty("webdriver.gecko.driver", "/home/shilpatailor/Driver/geckodriver");

		WebDriver driver = new FirefoxDriver();
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		 // Launch the Online Store Website using Constant Variabl
		
		driver.get(Constant.URL);
		
		// Pass Constant Variables as arguments to Execute method
		
		SignIn_Action.Execute(driver);
		
		System.out.println("Login Successfully, now it is the time to Log Off buddy.");
		
		Home_Page.lnk_LogOut(driver).click();
		
		Thread.sleep(5000);
		
		//driver.close();
	}

}
