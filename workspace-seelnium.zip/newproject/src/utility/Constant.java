package utility;

public class Constant {
	
	public static final String URL = "http://www.store.demoqa.com";
	
	public static final int Col_Username  = 1;
	
	public static final int Col_Password = 2;
	
	public static final String Path_TestData = "/home/shilpatailor/workspace/";
	
	public static final String File_Name = "TestData.xlsx";
	
	
	

}
