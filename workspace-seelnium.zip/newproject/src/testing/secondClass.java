package testing;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class secondClass {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.gecko.driver","/home/shilpatailor/Driver/geckodriver");
		
		WebDriver driver = new FirefoxDriver();
		
		String Url = "http://toolsqa.com/";
		
		driver.get(Url);
		
		String title = driver.getTitle();
		
		int titleLength = driver.getTitle().length();
		
		System.out.println("Title of the page is: " + title);
		
		System.out.println("Length of the title is " + titleLength);
		
		String actualUrl = driver.getCurrentUrl();
		
		if(actualUrl.equals(Url))
		{
			System.out.println("Verification is successful: The current URL is opened");
			
		}else {
			
			System.out.println("Verification is failed: The current URL is not opened");
			
			System.out.println("Actual URL is: " + actualUrl);
			System.out.println("Expected URL is: + Url");
		}
		
		String pageSource = driver.getPageSource();
		
		int pageSourceLength = pageSource.length();
		
		System.out.println("Total length of the page source is: " + pageSourceLength);
		
		//System.out.println("The page source is: " + pageSource);
		
		driver.close();

	}

}
