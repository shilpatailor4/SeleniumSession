package testing;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class firstClass {

	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.gecko.driver","/home/shilpatailor/Driver/geckodriver");
		
		WebDriver driver = new FirefoxDriver();
		
		driver.get("http://toolsqa.com/");
		
	    System.out.println("Open URL");
	
		Thread.sleep(5000);
		
		driver.quit();
	}

}
