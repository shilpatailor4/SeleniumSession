package testing;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class fourthClass {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.gecko.driver", "/home/shilpatailor/Driver/geckodriver");
		
		WebDriver driver = new FirefoxDriver();
		
		String Url = "http://toolsqa.wpengine.com/automation-practice-form/";
		
		driver.get(Url);
		
		driver.findElement(By.name("firstname")).sendKeys("");
		
		driver.findElement(By.name("lastname")).sendKeys("");
		
		

	}

}
