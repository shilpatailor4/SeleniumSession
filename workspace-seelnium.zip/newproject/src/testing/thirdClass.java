package testing;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class thirdClass {

	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.gecko.driver", "/home/shilpatailor/Driver/geckodriver");
		
		WebDriver driver = new FirefoxDriver();
		
		String appUrl = "http://www.DemoQA.com";
		
		driver.get(appUrl);
		
		driver.findElement(By.xpath(".//*[@id='menu-item-374']/a")).click();
		
		Thread.sleep(5000);
		
		driver.navigate().back();
		
		Thread.sleep(4000);
		
		driver.navigate().forward();
		
		driver.navigate().to(appUrl);
		
		driver.navigate().refresh();
		
		Thread.sleep(4000);
		
		driver.close();
		

	}

}
