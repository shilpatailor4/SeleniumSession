package appModule;

import org.openqa.selenium.WebDriver;
import pageObjects.Home_Page;
import pageObjects.LogIn_Page;
import utility.ExcelUtils;

public class SignIn_Action {
	
	/* public static void Execute(WebDriver driver) throws IOException {
		
		Home_Page.lnk_MyAccount(driver).click();
		
		LogIn_Page.txtbx_UserName(driver).sendKeys("shilpatailor");
		
		LogIn_Page.txtbx_Password(driver).sendKeys("test@123");
		
		LogIn_Page.txtbx_Login(driver).click();
		
	}  */
	
	 // Pass Arguments (Username and Password) as string
	
     //public static void Execute(WebDriver driver, String sUsername, String sPassword) throws Exception {
	public static void Execute(WebDriver driver) throws Exception{ 
    	 
    	//This is to get the values from Excel sheet, passing parameters (Row num &amp; Col num)to getCellData method
    	 String sUsername = ExcelUtils.getCellData(1, 1);
    	 
    	 String sPassword = ExcelUtils.getCellData(1, 2);
    	 
    	 Home_Page.lnk_MyAccount(driver).click();
    	 
    	 // Enter sUsername variable in place of hardcoded value
    	 LogIn_Page.txtbx_UserName(driver).sendKeys(sUsername);
    	 
    	// Enter sPassword variable in place of hardcoded value
    	 LogIn_Page.txtbx_Password(driver).sendKeys(sPassword);
    	 
    	 LogIn_Page.txtbx_Login(driver).click();
     }


		
	}
	


