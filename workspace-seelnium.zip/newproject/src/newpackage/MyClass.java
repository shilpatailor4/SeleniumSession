package newpackage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
//import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class MyClass {

	public static void main(String[] args) throws InterruptedException {
		// Create a new instance of the Chrome driver
		// System.setProperty("webdriver.chrome.driver","/home/shilpatailor/Driver/chromedriver");
		System.setProperty("webdriver.gecko.driver", "/home/shilpatailor/Driver/geckodriver");

		// Launch the RIE18 Website
		// WebDriver driver = new ChromeDriver();
		WebDriver driver = new FirefoxDriver();

		driver.get("http://www.riesthaan.com");

		// Print a Log In message to the screen
		System.out.println("Successfully opened the website http://www.riesthaan.com");

		// Wait for 5 Sec
		Thread.sleep(5000);
		WebElement login = driver.findElement(By.xpath("/html/body/div[1]/header/div/div/div/div/div/div/div[2]/div[1]/div/a"));
		login.click();

		Thread.sleep(3000);

		WebElement userid = driver.findElement(By.id("emailaddr"));
		userid.sendKeys("mdo@gkd-india.com");

		WebElement userpass = driver.findElement(By.id("password"));
		userpass.sendKeys("1892");

		WebElement submitbtn = driver.findElement(By.id("submitbtn"));
		submitbtn.click();

		Thread.sleep(5000);
		WebElement itinerary = driver.findElement(By.xpath("/html/body/div[1]/div/div/div/article/div/aside/div/div/ul/li[2]/a"));
		Thread.sleep(5000);
		itinerary.click();
		
		// Thread.sleep(5000);
		// WebElement home = driver.findElement(By.linkText("Home"));
		// home.click();

		// Go back to Home Page
		driver.navigate().back();
		Thread.sleep(5000);

		WebElement username = driver.findElement(By.className("dropdown-toggle"));
		username.click();

		Thread.sleep(5000);
		WebElement logout = driver.findElement(By.linkText("Log Out"));
		logout.click();
		
		System.out.println("Successfully logout the website http://www.riesthaan.com");

		Thread.sleep(5000);

		// Close the driver
		driver.quit();
		System.out.println("Successfully close the website http://www.riesthaan.com");

	}
}
