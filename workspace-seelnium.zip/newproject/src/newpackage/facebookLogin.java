package newpackage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class facebookLogin {
    public static void main(String[] args) throws InterruptedException {
    	System.setProperty("webdriver.gecko.driver","/home/shilpatailor/Driver/geckodriver");
        
        WebDriver driver = new FirefoxDriver();
        
        driver.get("https://www.facebook.com/");
        
        System.out.println("Successfully opened the website \"https://www.facebook.com/");
        
        Thread.sleep(3000);
        
        //driver.close();
        WebElement login = driver.findElement(By.xpath("//*[@id=\"email\"]"));
        login.sendKeys("testxyz231@gmail.com");
        
        WebElement pass = driver.findElement(By.id("pass"));
        pass.sendKeys("test@123");
        
        WebElement submit = driver.findElement(By.id("loginbutton"));
        submit.click();
        
        //Thread.sleep(5);
        
        WebElement arrow = driver.findElement(By.className("_5lxt"));
        arrow.click();
        Thread.sleep(5000);
        
        WebElement logOut = driver.findElement(By.partialLinkText("Log out"));
        Thread.sleep(2000);
        logOut.click();
        Thread.sleep(4000);
        
        System.out.println("Successfully logOut the website \\\"https://www.facebook.com/");

        
        Thread.sleep(4);
        driver.close();
    }

}
