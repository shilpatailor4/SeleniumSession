package arabera_LMS;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class araberaClass {
	
	//WebDriver driver;
	
	@BeforeTest
	//public void setUp() {
		//System.out.println("check");
	//}
		
		/*System.setProperty("webdriver.gecko.driver","/home/shilpatailor/selenium Driver/geckodriver");
		driver = new FirefoxDriver();
		
		driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.manage().deleteAllCookies();
		driver.manage().window().maximize();
		
		driver.get("http://webhonchoz.com/arabera/");
		System.out.println(driver.getTitle());
		
		System.out.println("Success! Launch the website.");
	}
	*/
	@Test
	public void loginTest() {
		
		System.out.println("check2");
	}
		
		/*driver.findElement(By.xpath("//*[@id=\"collapsibleNavbar\"]/div/ul/li[2]/a")).click();
		driver.findElement(By.xpath("//*[@id=\"username\"]")).sendKeys("shilpa@mailinator.com");
		driver.findElement(By.xpath("//*[@id=\"password\"]")).sendKeys("12345678");
		
		//login button
		WebElement loginBtn = driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div[2]/div/form/button"));
		loginBtn.click();
	}
	*/
	/*@AfterTest
	public void tearDown() {
		
		driver.quit();
	}*/
	
	

}
