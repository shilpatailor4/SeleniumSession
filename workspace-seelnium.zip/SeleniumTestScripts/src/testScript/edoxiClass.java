package testScript;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class edoxiClass {

	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.gecko.driver", "/home/shilpatailor/selenium/geckodriver");
		WebDriver driver = new FirefoxDriver();
		
		driver.get("https://workdemo4u.com/arabera/");
		
		/*//SignUp
		driver.findElement(By.xpath("/html/body/div[1]/header/nav/div/div/div/ul/li[1]/a")).click();
		
		driver.findElement(By.name("first_name")).sendKeys("cozy1");
		driver.findElement(By.name("last_name")).sendKeys("scozy1");
		driver.findElement(By.name("password")).sendKeys("12345678");
		driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div[2]/div/form/div[11]/div/label[4]")).click();
		driver.findElement(By.id("subbutton")).click();
		
		System.out.println("Successfully, Registered!");
		
		//driver.wait(5000);
*/		
		
		//Login
		driver.findElement(By.xpath("/html/body/div[1]/header/nav/div/div/div/ul/li[2]/a/h6")).click();
		driver.findElement(By.name("username")).sendKeys("sup@mailinator.com");
		driver.findElement(By.name("password")).sendKeys("12345678");
		driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div[2]/div/form/button")).click();
		System.out.println("Login successfully!");
		
		Thread.sleep(3000);
		
		//Create Post
		driver.findElement(By.name("title")).sendKeys("The harder you work for something, the greater you'll feel when you achieve it.");
		driver.findElement(By.id("btnSubmit")).click();
		System.out.println("Post created successfully!");
		
		// This  will scroll down the page by  1000 pixel vertical
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("window.scrollBy(0,400)");
		
		driver.findElement(By.xpath("/html/body/div[3]/div[3]/div/div/div[2]/div[3]/div[3]/div[1]/a[1]/img[2]")).click();
		
		Thread.sleep(4000);
		//driver.close();

	}

}
