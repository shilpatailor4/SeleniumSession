package testScript;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class facebookLogin {

	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.gecko.driver", "/home/shilpatailor/selenium/geckodriver");
		WebDriver driver = new FirefoxDriver();
		
		driver.get("https://www.facebook.com/");
		driver.getPageSource();
		driver.getTitle();
		
		//driver.wait(5000);
		driver.navigate().to("https://www.edureka.co/blog/what-is-selenium/");
		
		driver.navigate().back();
		driver.navigate().refresh();
		//driver.wait(5000);
		
		driver.findElement(By.name("email")).sendKeys("testxyz231@gmail.com");
		driver.findElement(By.name("pass")).sendKeys("test@123");
		driver.findElement(By.id("loginbutton")).click();
		
		driver.close();

	}

}
