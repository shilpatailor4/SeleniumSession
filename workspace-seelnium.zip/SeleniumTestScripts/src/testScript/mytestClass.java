package testScript;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class mytestClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.gecko.driver", "/home/shilpatailor/selenium/geckodriver");
		WebDriver driver = new FirefoxDriver();
		
		driver.get("https://workdemo4u.com/arabera/");
		
		String i = driver.getCurrentUrl();
		System.out.println(i);
		
		String j = driver.getTitle();
		System.out.println("Actual title is:" +j);
		
		//Asserts.assertEquals("only testing", j);
		

		driver.close();
	}

}
