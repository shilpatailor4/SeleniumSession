package arabera_Lms;

import java.util.concurrent.TimeUnit;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import utill.testUtill;

public class araberaClass {
	
	WebDriver driver;
	
	@BeforeTest
	public void setUp() throws InterruptedException {
		System.out.println("check");
	
		
		System.setProperty("webdriver.gecko.driver","/home/shilpatailor/selenium Driver/geckodriver");
		driver = new FirefoxDriver();
		
		driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.manage().deleteAllCookies();
		driver.manage().window().maximize();
		
		driver.get("http://www.webhonchoz.com/arabera/login");
		//driver.findElement(By.xpath("//*[@id=\"collapsibleNavbar\"]/div/ul/li[2]/a")).click();
		
		System.out.println(driver.getTitle());
		
		System.out.println("Success! Launch the website.");
		
		Thread.sleep(3000);
	}
	@Test(dataProvider="loginData")
	public void getLoginData(String username, String password) throws InterruptedException {
		
		System.out.println("check2");
		driver.get("http://www.webhonchoz.com/arabera/login");
		driver.findElement(By.xpath("//*[@id=\"username\"]")).sendKeys(username);
		driver.findElement(By.xpath("//*[@id=\"password\"]")).sendKeys(password);
		
		//login button
		driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div[2]/div/form/button")).click();
		Thread.sleep(5000);
	}
	@DataProvider(name="loginData")
	public Object[][] getLoginData() throws InvalidFormatException{
		testUtill config=new testUtill("/home/shilpatailor/selenium/arabera_excel/LoginTestData.xls");
		int row =testUtill.getRowCount(0);
      	Object[][] data =new Object[row][2];
		//Object data[][] = testUtill.getTestData("login");
		System.out.println("check1");
		for(int i=1;i<row;i++) {
	 		data[i][0]=testUtill.getData(0, i, 0);
	 		data[i][1]=testUtill.getData(0, i, 1);
	    }
		
	    return data;	
		
	}
/*	
	@AfterTest
	public void tearDown() {
		
		driver.quit();
	}
	*/
	
}
