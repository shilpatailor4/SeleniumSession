package utill;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class testUtill {
	
/*	static Workbook book;
	static Sheet sheet;
*/	
	private static HSSFWorkbook ExcelWBook;
    public static HSSFSheet ExcelWSheet;
    public static HSSFCell Cell;
    private static HSSFRow Row;

	
	//public static String TESTDATA_SHEET_PATH = "/home/shilpatailor/selenium/arabera_excel/LoginTestData.xlsx";
	
	public testUtill(String excelPath) {

		try {
		File src=new File(excelPath);
		FileInputStream fis=new FileInputStream(src);
		ExcelWBook=new HSSFWorkbook(fis);
		//wb=new XSSFWorkbook(fis);
		} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		}
		}
	/*public static Object[][] getTestData(String sheetName) throws InvalidFormatException {
			
			FileInputStream file = null;
			try {
				
				file = new FileInputStream(TESTDATA_SHEET_PATH);
			} catch(FileNotFoundException e) {
				e.printStackTrace();
		    }
			
			try {
				
				book = WorkbookFactory.create(file);
			} catch (IOException e) {
				e.printStackTrace();
			}
			
			sheet = book.getSheet(sheetName);
			Object[][] data = new Object[sheet.getLastRowNum()][sheet.getRow(0).getLastCellNum()];
			
			for(int i = 0; i < sheet.getLastRowNum(); i++) {
				for(int k = 0; k < sheet.getRow(0).getLastCellNum(); k++) {
					data[i][k] = sheet.getRow(i + 1).getCell(k).toString();
				}
			}
			
			return data;
			
		}
	*/
	public static String getData(int sheetNumber,int row,int column) {
		System.out.println("value of column= "+column);
		//System.out.println(testUtill.getRow(1).getCell(1).getStringCellValue());
   		//sheet1=	wb.getSheetAt(sheetNumber);
		//System.out.println();
		ExcelWSheet=ExcelWBook.getSheetAt(sheetNumber);
		//String data=sheet1.getRow(row).getCell(column).getStringCellValue();
		Cell = ExcelWSheet.getRow(row).getCell(column);
		//data=ExcelWSheet.getRow(row).getCell(column).getStringCellValue();
		DataFormatter formatter = new DataFormatter();
		String cellData = formatter.formatCellValue(Cell);
		
		//String data=ExcelWSheet.getRow(row).getCell(column).getStringCellValue();
		//String data =ExcelWSheet.getRow(rw).get
		return cellData;
	}
	private static HSSFRow getRow(int i) {
		// TODO Auto-generated method stub
		return null;
	}
	//count no of rows in excel sheet
	public static int getRowCount(int sheetIndex){
		int row=0;
		//int row=wb.getSheetAt(sheetIndex).getLastRowNum();
		row=ExcelWBook.getSheetAt(sheetIndex).getLastRowNum();
		row =row+1;
		return row;
	}	
//====================================
}

