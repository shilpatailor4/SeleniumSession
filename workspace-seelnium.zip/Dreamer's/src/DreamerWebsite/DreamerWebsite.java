package DreamerWebsite;

import org.openqa.selenium.By;
import org.openqa.selenium.By.ByName;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class DreamerWebsite {
	public static void main(String[] arg) throws InterruptedException {
		System.setProperty("webdriver.gecko.driver","/home/shilpatailor/Driver/geckodriver");
		WebDriver driver = new FirefoxDriver();
		
		String Url = "http://relianttekk.com/dreamers/upload/users/member_login";
		
		driver.navigate().to(Url);
		
		System.out.println("Sccessfully lunch a website Url.");
		
//      driver.findElement(By.id("sign-up-link")).click();
//		
//		driver.findElement(By.xpath("//*[@id=\"name\"]")).sendKeys("shilpa tailor");
//	
//		driver.findElement(By.xpath("//*[@id=\"email\"]")).sendKeys("shilpa6@gmail.com");
//		
//		driver.findElement(By.xpath("//*[@id=\"password\"]")).sendKeys("123456");
//		
//		driver.findElement(By.xpath("//*[@id=\"password2\"]")).sendKeys("123456");
//		
//		Thread.sleep(2000);
//		
//		WebElement submit = driver.findElement(By.id("submitFormsignup"));
//		submit.click();
//		
//		System.out.println("Successfully continue with sign up dreamer website account.");
//		Thread.sleep(3000);
//		
//		WebElement upload = driver.findElement(By.name("file"));
//		Thread.sleep(3000);
//		
//	    upload.sendKeys("/home/shilpatailor/Desktop/123.jpg");
//	    
//	    Select select = new Select(driver.findElement(By.tagName("select")));
//	    select.selectByVisibleText("May");
//	    
//	    driver.findElement(By.id("birthdayDay")).sendKeys("29");
//	    driver.findElement(By.id("birthdayYear")).sendKeys("2000");
//	    
//	    driver.findElement(By.id("timezone")).sendKeys("Asia/Kolkata");	    
//	    driver.findElement(By.id("gender")).sendKeys("Female");
//	    
//	    driver.findElement(By.id("tos")).click();
//	    
//	    Thread.sleep(3000);
//	    driver.findElement(By.id("step2Submit")).click();
//	    Thread.sleep(3000);
//	    
//	    System.out.println("Register successfully");
	    
	    //Login Dreamer Website
	    
	    driver.findElement(By.id("login_email")).sendKeys("shilpa4@gmail.com");
	    
	    driver.findElement(By.id("login_password")).sendKeys("123456");
	    
	    Thread.sleep(5000);
	    
	    driver.findElement(By.xpath("/html/body/div[4]/section[1]/div/div/div/div/div[2]/div/div/div[2]/div/div/div[1]/div/div/div/form/div[5]/div/div/input")).click();
	    
	    Thread.sleep(5000);
	    
	    System.out.println("sign in successfully"); 
	    
	    //Page scroll
	     JavascriptExecutor jse = (JavascriptExecutor)driver;
	     jse.executeScript("window.scrollBy(0,900)", "");
	    
	    // Create a new post
	       
	    System.out.println("Post created successfully");
	    
	    //Add location address
	    
	    driver.findElement(By.className("map-icon")).click();
	    Thread.sleep(3000);
	    driver.findElement(By.xpath("//*[@id=\"searchInput\"]")).sendKeys("Jaipur, Jaipur, Rajasthan, India");
	    Thread.sleep(4000);
	    
        //Page scroll
	    JavascriptExecutor jse1 = (JavascriptExecutor)driver;
	    jse1.executeScript("window.scrollBy(0,700)", "");
	    
	    driver.findElement(By.id("checkin_btn")).click();
	    Thread.sleep(3000);
	    
	    driver.findElement(By.id("message")).sendKeys("Hello my first script");
	    Thread.sleep(3000);
		
	    driver.findElement(By.id("status_btn")).click();
	    
	    System.out.println("Created post successfully");
	  //This  will scroll page 400 pixel vertical
		   ((JavascriptExecutor)driver).executeScript("scroll(0,400)");
	    Thread.sleep(5000);
	    
	    //opens My fulfilled dreams page
	    driver.findElement(By.linkText("My fulfilled dreams")).click();
	    System.out.println("Successfully opens the My fulfilled dreams page");
	    Thread.sleep(5000);
	    
	    driver.navigate().back();
	    
	  //opens Dreams fulfilled by me page
	    driver.findElement(By.linkText("Dreams fulfilled by me")).click();
	    System.out.println("Successfully opens the Dreams fulfilled by me page");
	  
	    Thread.sleep(5000);
	    
	    driver.navigate().back();
		
		driver.close();
	}

}
