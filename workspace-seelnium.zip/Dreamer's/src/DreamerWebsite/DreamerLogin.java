package DreamerWebsite;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;


public class DreamerLogin {

    
        @Test
        public void Login() throws IOException, EncryptedDocumentException, InvalidFormatException {

        WebDriverWait wait;
        XSSFWorkbook workbook = null;
        XSSFSheet sheet1 = null; 
        XSSFCell cell1 = null;
        XSSFSheet Sheet = null;
        // Import excel sheet.

        File src=new File("/home/shilpatailor/Desktop/dreamerLogin.xlsx");

        // Load the file.

        FileInputStream finput = null;
        try {
        finput = new FileInputStream(src);
        } catch (FileNotFoundException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
        }


        // Load he workbook.

        try {
        workbook = new XSSFWorkbook(finput);
        } catch (IOException e1) {
        // TODO Auto-generated catch block
        e1.printStackTrace();
        }

        // Load the sheet in which data is stored.

        sheet1= workbook.getSheetAt(0);



        for(int i=1; i<sheet1.getLastRowNum(); i++)
        {

        	System.setProperty("webdriver.gecko.driver","/home/shilpatailor/Driver/geckodriver");
        WebDriver driver = new FirefoxDriver();

        driver.get("http://relianttekk.com/dreamers/upload/users/member_login"); 



        // Import data for Email.

        cell1 = sheet1.getRow(i).getCell(1);

        cell1.setCellType(Cell.CELL_TYPE_STRING);

        driver.findElement(By.id("login_email")).sendKeys(cell1.getStringCellValue());



        // Import data for password.

        cell1 = sheet1.getRow(i).getCell(2);

        cell1.setCellType(Cell.CELL_TYPE_STRING);

        driver.findElement(By.id("login_password")).sendKeys(cell1.getStringCellValue());

        driver.findElement(By.xpath("/html/body/div[4]/section[1]/div/div/div/div/div[2]/div/div/div[2]/div/div/div[1]/div/div/div/form/div[5]/div/div/input")).click();
        
        
        InputStream inp = new FileInputStream("/home/shilpatailor/Desktop/dreamerLogin.xlsx");


        Workbook wb = WorkbookFactory.create(inp);
        XSSFSheet XSSFSheet = (XSSFSheet)wb.getSheetAt(0);

        Row row = ((XSSFSheet) XSSFSheet).getRow(1);
        Cell cell = row.getCell(3);
        if (cell == null)
        cell = row.createCell(3);
        cell.setCellType(Cell.CELL_TYPE_STRING);
        cell.setCellValue("Pass");

        // Write the output to a file
        FileOutputStream fileOut = new FileOutputStream("/home/shilpatailor/Desktop/dreamerLogin.xlsx");
        wb.write(fileOut);
        fileOut.close();


	}}}


