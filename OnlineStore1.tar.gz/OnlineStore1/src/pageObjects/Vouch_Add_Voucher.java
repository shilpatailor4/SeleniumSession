package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import utility.Log;
public class Vouch_Add_Voucher extends BaseClass {
           private static WebElement element = null;
        
        public Vouch_Add_Voucher(WebDriver driver){
            	super(driver);
        }     
        
        
        public static WebElement btn_menu() throws Exception
        {
        	try {
        		//Thread.sleep(5000);
				element = driver.findElement(By.xpath("/html/body/div[1]/header[1]/div/nav/div[3]/div/ul/li[2]/label/div/i"));
														
				Log.info("Vouchers Showing on Menu list");
				
        		
			} catch (Exception e) {
				Log.error("Vouchers not found in the Menu list");
				throw(e);
			}
        return element;
        }
        
        public static WebElement btn_Voucher() throws Exception{
        	
        	try{
        		System.out.println("under menu");
        		//Thread.sleep(5000);
        		
	            element = driver.findElement(By.xpath("/html/body/div[1]/header[1]/div/nav/div[3]/div/ul/li[2]/label/div/ul/li[3]/a"));
	           
	            Log.info("Vouchers page open successfully");
        	}catch (Exception e){
           		Log.error("Vouchers Page not Open");
           		throw(e);
           		}
           	return element;
            }
        
       public static WebElement btn_Add_Voucher() throws Exception
        {
    	   System.out.println("AAYA");
        	try{
        		System.out.println("AAYA1");       		
        		//Thread.sleep(5000);
	        	element = driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[3]/div/div/div/div/div/div[1]/div/a"));
	        	System.out.println("E2");									
	            Log.info("Add New Voucher page open successfully");
        	}catch (Exception e){
        		System.out.println("E3");
        		Log.error("Add New Voucher is Not Open");
           		throw(e);
           		}
           	return element;
        }
        
   public static WebElement txt_Vouchertitle() throws Exception{
        	try{
        		Thread.sleep(5000);
	        	element = driver.findElement(By.name("title"));
	            Log.info("Title is found on the Add Voucher");
        	}catch (Exception e){
        		Log.error("Title is not found on the Add Voucher");
           		throw(e);
           		}
           	return element; 
        }

        public static WebElement upload_Voucherimage() throws Exception{
        	try{
        		Thread.sleep(5000);
        	
	        	element = driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[3]/div/div/div/div/div/div[3]/form/div[2]/div/label/input"));
	            Log.info("Image Browse on the Add Voucher");
        	}catch (Exception e){
        		Log.error("Image Browse not found on the Add Voucher");
           		throw(e);
           		}
           	return element;
        }
        public static WebElement Dropdown_click() throws Exception{
        	try{
        		Thread.sleep(5000);
        	
	        	element = driver.findElement(By.name("category_id"));
	            Log.info("DropDown Click on the Add Voucher");
        	}catch (Exception e){
        		Log.error("DropDown not found on the Add Voucher");
           		throw(e);
           		}
           	return element;
        }
        public static WebElement Dropdown_select() throws Exception{
        	try{
        		Thread.sleep(5000);
        	
	        	element = driver.findElement(By.name("category_id"));
	            Log.info("Select item from Dropdown list on the Add Voucher");
        	}catch (Exception e){
        		Log.error(" Item not select from the Dropdown");
           		throw(e);
           		}
        	return element;
        }

        public static WebElement Add_Description() throws Exception{
        	try{
        		       	
	        	element = driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[3]/div/div/div/div/div/div[3]/form/div[4]/textarea"));
	            Log.info(" Showing Description on the Add Voucher");
        	}catch (Exception e){
        		Log.error("Description not Showing on the Add Voucher");
           		throw(e);
           		}
        	return element;
        }
        public static WebElement Add_Miniprice() throws Exception{
        	try{
        		       	
	        	element = driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[3]/div/div/div/div/div/div[3]/form/div[5]/div[2]/div[1]/input"));
	            Log.info(" Showing Minimium Price on Add Voucher");
        	}catch (Exception e){
        		Log.error(" Minimum Price not Showing on the Add Voucher");
           		throw(e);
           		}
        	return element;
        }

        public static WebElement Add_Maxprice() throws Exception{
        	try{
        		       	
	        	element = driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[3]/div/div/div/div/div/div[3]/form/div[5]/div[2]/div[2]/input"));
	            Log.info(" Showing Maximium Price on Add Voucher");
        	}catch (Exception e){
        		Log.error(" Maximum Price not Showing on the Add Voucher");
           		throw(e);
           		}
        	return element;
        }

        public static WebElement Added_Voucher() throws Exception{
        	try{
        		       	
	        	element = driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[3]/div/div/div/div/div/div[3]/form/div[5]/button"));
	            Log.info(" Add Button on Add Voucher");
        	}catch (Exception e){
        		Log.error(" Add button not Showing on the Add Voucher");
           		throw(e);
           		}
        	return element;
        }


}


