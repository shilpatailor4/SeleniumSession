package utility;

public class Constant {
	    public static final String URL = "https://www.relianttekk.com/shubhashishvouch/signup";
	 //   public static final String Username = "demo@admin.com";
	  //  public static final String Password ="123456";
		public static final String Path_TestData ="/home/vikas/";
		public static final String File_TestData ="Online.xls";
		
		//Test Data Sheet Columns
		public static final int Col_TestCaseName = 0;	
		public static final int Col_UserName =1 ;
		public static final int Col_Password = 2;
		public static final int Col_Browser = 3;
		public static final int Col_VoucherTitle = 4;
		public static final int Col_ChooseCategory = 5;
		public static final int Col_Description = 6;
		public static final int Col_MinimumPrice = 7;
		public static final int Col_MaximumPrice = 8;
		public static final int Col_Image = 9;
		public static final int Col_Country = 10;
		public static final int Col_Phone = 11;
		public static final int Col_Email = 12;
		public static final int Col_Result = 13;
		public static final String Path_ScreenShot = "/home/vikas/eclipse-workspace/OnlineStore1/src/Screenshots/New folder/";
	}
