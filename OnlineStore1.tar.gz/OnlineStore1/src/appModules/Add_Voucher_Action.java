package appModules;

import org.openqa.selenium.support.ui.Select;
import org.testng.Reporter;
import org.testng.annotations.Test;
import pageObjects.Vouch_Add_Voucher;
import utility.Constant;
import utility.ExcelUtils;
import utility.Log;
     
    // This is called Modularization, when we club series of actions in to one Module
	// For Modular Driven Framework, please see http://www.toolsqa.com/modular-driven/ 
    @Test
   public class Add_Voucher_Action {
    	// iTestcaseRow is the row number of our Testcase name in the Test Data sheet
    	// iTestcaseRow is passed as an Argument to this method, so that it can used inside this method
    	// For use of Functions & Parameters, please see http://www.toolsqa.com/function-parameters/
        public static void Execute(int iTestCaseRow) throws Exception{
        	
        	// Clicking on the My Account link on the Home Page
        	//Home_Page.lnk_MyAccount().click();
        	//Log.info("Click action is perfromed on My Account link" );
        	
        	// Storing the UserName in to a String variable and Getting the UserName from Test Data Excel sheet
        	// iTestcaseRow is the row number of our Testcase name in the Test Data sheet
        	// Constant.Col_UserName is the column number for UserName column in the Test Data sheet
        	// Please see the Constant class in the Utility Package
        	// For Use of Constant Variables, please see http://www.toolsqa.com/constant-variables/
        	
        	//Click On Menu for go to  Voucher Screen.
        	Vouch_Add_Voucher.btn_menu().click();
        	
        	Log.info("CLick action is performed on Menu");
 
        	//String sUserName = ExcelUtils.getCellData(iTestCaseRow, Constant.Col_UserName);
        	//System.out.println ("user name is :" + sUserName);
        	// Here we are sending the UserName string to the UserName Textbox on the LogIN Page
        	// This is call Page Object Model (POM)
        	// For use of POM, please see http://www.toolsqa.com/page-object-model/
          
        	Vouch_Add_Voucher.btn_Voucher().click();
        	
            // Printing the logs for what we have just performed
            Log.info( "Voucher screen open Successfully" );
            
            
            System.out.println("AAYA abhi");
            Vouch_Add_Voucher.btn_Add_Voucher().click();
            System.out.println("AAYA abhi abhi");
            Log.info( "Add New Voucher Click Successfully" );
            
            try {
            	String title= ExcelUtils.getCellData(iTestCaseRow, Constant.Col_VoucherTitle);
                System.out.println("Title is:" + title);
                Vouch_Add_Voucher.txt_Vouchertitle().sendKeys(title);
                Log.info( "Title Added Successfully" );
			} catch (Exception e) {
				Log.error("Title Does not Add");
				throw(e);
							}
            
            try {
            	String browse= ExcelUtils.getCellData(iTestCaseRow, Constant.Col_Image);
                System.out.println("Image Path is:" + browse);
                Thread.sleep(5000);
                Vouch_Add_Voucher.upload_Voucherimage().sendKeys(browse);
                Thread.sleep(5000);
                Log.info( "Image uploaded Successfully" );
			} catch (Exception e) {
				Log.error("Image Not Uploaded");
				throw(e);
							}
            
           
            
            try {
            	              
                Thread.sleep(5000);
                Vouch_Add_Voucher.Dropdown_click().click();
                Log.info( "Dropdown Click Successfully" );
			} catch (Exception e) {
				Log.error("Dropdown is Not Click");
				throw(e);
							}

            
            try {
            	Thread.sleep(5000);
            	String dropdown= ExcelUtils.getCellData(iTestCaseRow, Constant.Col_ChooseCategory);
                System.out.println("Select value is:" + dropdown);
                Select oselect =  new Select(Vouch_Add_Voucher.Dropdown_select());
                oselect.selectByVisibleText(dropdown);
                Thread.sleep(5000);
                Log.info( "Item is added Successfully" );
			} catch (Exception e) {
				Log.error("Item is not added");
				throw(e);
							}
            
            try {
            	String desc= ExcelUtils.getCellData(iTestCaseRow, Constant.Col_Description);
                System.out.println("Description is:" + desc);
                Vouch_Add_Voucher.Add_Description().sendKeys(desc);
                Log.info( "Description Added Successfully" );
			} catch (Exception e) {
				Log.error("Description Does not Add");
				throw(e);
							}
            
            
            try {
            	String min= ExcelUtils.getCellData(iTestCaseRow, Constant.Col_MinimumPrice);
                System.out.println("Minimum Price is:" + min);
                Vouch_Add_Voucher.Add_Miniprice().sendKeys(min);
                Log.info( "Minimum Price Added Successfully" );
			} catch (Exception e) {
				Log.error("Minimium Price Does not Add");
				throw(e);
							}
            
            try {
            	String max= ExcelUtils.getCellData(iTestCaseRow, Constant.Col_MaximumPrice);
                System.out.println("Maximum Price is:" + max);
                Vouch_Add_Voucher.Add_Maxprice().sendKeys(max);
                Log.info( "Maximum Price Added Successfully" );
			} catch (Exception e) {
				Log.error("Maximum Price Does not Add");
				throw(e);
							}
            

            try {
            	              
                Thread.sleep(5000);
                Vouch_Add_Voucher.Added_Voucher().click();
                Log.info( "Voucher Added Successfully" );
			} catch (Exception e) {
				Log.error("Voucher is Not Added");
				throw(e);
							}
            
            //String sPassword = ExcelUtils.getCellData(iTestCaseRow, Constant.Col_Password);
            //System.out.println ("password is :" + sPassword);
            //Vouch_LogIn_Page.txtbx_Password().sendKeys(sPassword);
            //Log.info(sPassword+" is entered in Password text box" );
            
           //Vouch_LogIn_Page.btn_LogIn().click();
            //Log.info("Click action is performed on Submit button");
            
            // I noticed in few runs that Selenium is trying to perform the next action before the complete Page load
            // So I have decided to put a wait on the Logout link element
            // Now it will wait 10 secs separately before jumping out to next step
           // Utils.waitForElement(Home_Page.lnk_LogOut());
            
            // This is another type of logging, with the help of TestNg Reporter log
            // This has to be very carefully used, you should only print the very important message in to this
            // This will populate the logs in the TestNG HTML reports
            // I have used this Reporter log just once in this whole module 
            Reporter.log(" Add New Voucher Screen Open Successfully");
  
        }
    }
