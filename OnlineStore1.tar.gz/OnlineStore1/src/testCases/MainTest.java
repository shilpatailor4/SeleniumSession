package testCases;

import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import appModules.SignIn_Action;
import pageObjects.BaseClass;
import appModules.Add_Voucher_Action;
import utility.Constant;
import utility.ExcelUtils;
import utility.Log;
import utility.Utils;

@Test
public class MainTest {


public WebDriver driver;
private String sTestCaseName ="testcase";
private int iTestCaseRow;

@BeforeMethod
public void beforeMethod() throws Exception {


	DOMConfigurator.configure("log4j.xml");

// sTestCaseName = this.toString();

// sTestCaseName = Utils.getTestCaseName(this.toString());


	Log.startTestCase(sTestCaseName);


	ExcelUtils.setExcelFile(

			Constant.Path_TestData + Constant.File_TestData, "Sheet1");


}

// This is the starting of the Main Test Case
public void main() throws Exception {
	
			for (int i =0; i<2; i++) {

		try {
        			iTestCaseRow = ExcelUtils.getRowContains(sTestCaseName+i,Constant.Col_TestCaseName);


			driver = Utils.OpenBrowser(iTestCaseRow);
			Utils.takeScreenshot(driver, sTestCaseName+i);
			new BaseClass(driver);


			SignIn_Action.Execute(iTestCaseRow);
			Add_Voucher_Action.Execute(iTestCaseRow);

		
			if (BaseClass.bResult == true) {


				System.out.println("Pass");


			} 
			
			else {
//throw new Exception("Test Case Failed because of Verification");

	
				System.err.println("Test Case Failed because of Verification");

			}


		}
		catch (Exception e) {

	System.out.println("Fail");

	Utils.takeScreenshot(driver, sTestCaseName+i);

	Log.error(e.getMessage());
//throw (e);

	e.printStackTrace();
}
		Utils.takeScreenshot(driver, sTestCaseName+i);
Log.endTestCase(sTestCaseName+i);
//driver.close();
}

}

// }
// Its time to close the finish the test case
@AfterMethod
public void afterMethod() throws InterruptedException {


driver.close();
}
}