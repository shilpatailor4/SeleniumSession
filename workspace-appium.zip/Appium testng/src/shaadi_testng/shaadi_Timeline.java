package shaadi_testng;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.util.Date;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.annotations.Test;

import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.offset.PointOption;

public class shaadi_Timeline extends shaadi_Home {
	
	String folder_name;
    DateFormat df;
	
//=======================Take screenshot====================================
	
	public void captureScreenShots(String file_name) throws IOException {
        folder_name="screenshot";
        File f=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        //create dir with given folder name
        new File(folder_name).mkdir();
        //Setting file name
        file_name=df.format(new Date())+".png";
        //coppy screenshot file into screenshot folder.
        FileUtils.copyFile(f,new File(folder_name + "/" + file_name));
    }
	
//=======================Open Leadership===========================================
	
	@Test(priority=1)
	public static void doLeaderboard() throws InterruptedException {
		
		driver.findElementById("com.theshaadi:id/btn_timeline").click();
		File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		System.out.println("Success! Leaderboard screen.");
		
		Thread.sleep(5000);
		
		driver.navigate().back();
		
		Thread.sleep(7000);
	}
	
 //=======================Create Post====================================
	      
	
	/*@Test(priority=2)
	public static void doCreatePost() throws InterruptedException {
		
		 //Create a new post
        
        driver.findElementById("com.theshaadi:id/btn_create_update").click();
        
        Thread.sleep(2000);
        
        // Write a message on post
        
        driver.findElementById("com.theshaadi:id/et_update_message").sendKeys("Weddings are important because they celebrate life and possibility.");
        driver.hideKeyboard();
        
        Thread.sleep(3000);
        
        //....
        
        //Attach image on device gallery
        
        driver.findElementById("com.theshaadi:id/iv_take_picture").click();
        
      
        Thread.sleep(1500);
         
        driver.findElementById("android:id/text1").click();
        
      //Handle pop up
        while (driver.findElements(MobileBy.id("com.android.packageinstaller:id/permission_allow_button")).size()>0) {
       	    driver.findElement(MobileBy.id("com.android.packageinstaller:id/permission_allow_button")).click();
       	}
        
        
       Thread.sleep(2000);
        
        //Click on post create (done) button
        
      driver.findElementById("com.theshaadi:id/iv_send_message").click();
        
        //screen scroll down to top
        
        
     

      System.out.println("The post created successfully");
      Thread.sleep(3000);
    
	}*/
	
	
 //======================Printing names of all the menus==============================
	
	@Test(priority=3)
	public static void sideMenu() throws InterruptedException {
		
		driver.findElementById("com.theshaadi:id/nav_open_img").click();
		
		//showing side menu listing (Printing names of all the menus)
		  
	      List<MobileElement> list = driver.findElementsById("com.theshaadi:id/design_menu_item_text");
	      System.out.println("Menu List size is " + list.size());
	      System.out.println(list.get(0).getText());
	      System.out.println(list.get(1).getText());
	      System.out.println(list.get(2).getText());
	      System.out.println(list.get(3).getText());
	      System.out.println(list.get(4).getText());
	      System.out.println(list.get(5).getText());
	      System.out.println(list.get(6).getText());
	      System.out.println(list.get(7).getText());
	      System.out.println(list.get(8).getText());
	      System.out.println(list.get(9).getText());
	      System.out.println(list.get(10).getText());
	      System.out.println(list.get(11).getText());
	      
	      (new TouchAction(driver))
	       .press(PointOption.point(547, 1457))
	       .moveTo(PointOption.point(547,0 ))
	       .release()
	       .perform();
	      
	      list = driver.findElementsById("com.theshaadi:id/design_menu_item_text");
	      System.out.println("check");
	      
	      //Thread.sleep(2000);
	      
	     TouchAction action1 = new TouchAction(driver);
	      
	   //================== Open profile screen==================================
	     
			System.out.println(list.get(0).getText());
			action1.tap(PointOption.point(230, 221)).perform();
			Thread.sleep(2000);
			
			//View user profile image
			driver.findElementById("com.theshaadi:id/iv_user_image").click();
			Thread.sleep(1500);
			File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			System.out.println("The user profile appears");
			driver.navigate().back();
			Thread.sleep(1500);
			
			//scroll screen
			(new TouchAction(driver))
            .press(PointOption.point(352, 0))
            .moveTo(PointOption.point(352, 1210))
            .release()
            .perform();
			
			driver.navigate().back();
			
	//======================Open Event Timeline screen=====================================		
			
			
			driver.findElementById("com.theshaadi:id/nav_open_img").click();
			System.out.println(list.get(1).getText());
			driver.findElementById("com.theshaadi:id/textViewPost").click();
			//action1.tap(PointOption.point(320, 443)).perform();
			Thread.sleep(2000);
			
			//Showing Event date
			List<MobileElement> list1 = driver.findElementsByClassName("android.widget.TextView");
			//List<MobileElement> list1 = driver.findElementsById("com.theshaadi:id/tv_title_toolbar");
		    System.out.println("Menu List size is " + list1.size());
		    System.out.println(list1.get(0).getText());
		    System.out.println(list1.get(1).getText());
		    System.out.println(list1.get(2).getText());
		    System.out.println(list1.get(3).getText());
		    System.out.println(list1.get(4).getText());
		    System.out.println(list1.get(5).getText());
		    System.out.println(list1.get(6).getText());
		    System.out.println(list1.get(7).getText());
		    System.out.println(list1.get(8).getText());
		    System.out.println(list1.get(9).getText());
		    System.out.println(list1.get(10).getText());
		    System.out.println("");
		    Thread.sleep(1000);
		    
		    //...............Detail showing 1st Event.....................
		    //System.out.println(list.get(3).getText());
		    driver.findElementById("com.theshaadi:id/circularImageView2").click();
		    Thread.sleep(1000);
		 	
			driver.findElementById("com.theshaadi:id/img_u_r_n_g").click();
			Thread.sleep(2000);
			driver.navigate().back();
			
			
		   //====================Guest Screen================================
			
			driver.findElement(By.id("com.theshaadi:id/nav_open_img")).click();

			System.out.println(list.get(2).getText());
			action1.tap(PointOption.point(230, 739)).perform();
			Thread.sleep(2000);
		    
			driver.findElement(By.id("com.theshaadi:id/search_views")).sendKeys("vikas");
			driver.findElement(By.id("com.theshaadi:id/circularImageView2")).click();
			Thread.sleep(2000);
			driver.navigate().back();
			
			
			//===================Bride & Groom family==============================
			
			driver.findElement(By.id("com.theshaadi:id/nav_open_img")).click();
			
			System.out.println(list.get(3).getText());
			action1.tap(PointOption.point(350, 857)).perform();
			Thread.sleep(2000);
			
			driver.findElement(By.id("com.theshaadi:id/circularImageView2")).click();
			Thread.sleep(2000);
			driver.navigate().back();
			
			
			//======================Local attraction==============================
			
            driver.findElement(By.id("com.theshaadi:id/nav_open_img")).click();
			
			System.out.println(list.get(3).getText());
			action1.tap(PointOption.point(372, 1054)).perform();
			Thread.sleep(2000);
			
			
		    
		
	}
	
	
}