package shaadi_testng;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.touch.offset.PointOption;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class shaadi_Home {
	
	public static AppiumDriver<MobileElement> driver;

	
	@BeforeTest
	  public void SetUp() throws InterruptedException, MalformedURLException {
	
		
		//Set the Desired Capabilities
		DesiredCapabilities caps = new DesiredCapabilities();
		caps.setCapability("deviceName", "My device");
		caps.setCapability("udid", "e5696a1a0703"); //Give Device ID of your mobile phone (adb devices) "e5696a1a0703(My-phone)/ZY223ZGH5D(MotoG5+)"
		caps.setCapability("platformName", "Android");
		caps.setCapability("platformVersion", "7.0");
		caps.setCapability("appPackage", "com.theshaadi");
		caps.setCapability("appActivity", "com.theshaadi.splash.SplashActivity");    // App Activity of Shaadi App  com.theshaadi.splash.SplashActivity
		caps.setCapability("autoGrantPermission","true");
		caps.setCapability("noReset", "true"); //Command to get App activity & package: (adb logcat) 
		//driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
	
		//Instantiate Appium Driver
			
				driver = new AndroidDriver<MobileElement>(new URL("http://127.0.0.1:4723/wd/hub"), caps);
				
				//Thread.sleep(2000);
     }
	
	     @Test
	     public void Screen() throws InterruptedException {
	    	 
		          driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
//		          driver.findElementByClassName("android.widget.ImageView").click();
		          
	    	 System.out.println("Success! Application Launch.");
	    	 
			          
		      /*//Scroll down    
		          (new TouchAction(driver))
                  .press(PointOption.point(1010, 1566)).waitAction()
                  .waitAction()
                  .moveTo(PointOption.point(1010, 0))
                  .release()
                  .perform();
		      
		      //Step-1
		          (new TouchAction(driver))
                  .press(PointOption.point(1010, 1566)).waitAction()
                  .waitAction()
                  .moveTo(PointOption.point(1010, 0))
                  .release()
                  .perform();
		      
		      //Step-2
		          (new TouchAction(driver))
                  .press(PointOption.point(1010, 1566)).waitAction()
                  .waitAction()
                  .moveTo(PointOption.point(1010, 0))
                  .release()
                  .perform();
		          
	         
	              Thread.sleep(2000);
	        
	  
	         // SCroll Up
	             (new TouchAction(driver))
                 .press(PointOption.point(1010, 0))
                 .moveTo(PointOption.point(1010,1566 ))
                 .release()
                 .perform();*/
	             
	             Thread.sleep(3000);
	  
	
       }
	

  }
 
		   
