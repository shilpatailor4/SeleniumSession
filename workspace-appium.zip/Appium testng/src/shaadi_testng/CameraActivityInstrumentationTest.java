package shaadi_testng;

import org.testng.annotations.Test;

public class CameraActivityInstrumentationTest extends shaadi_Home {
	
	
	
	@Test
	public void captureImage() throws InterruptedException {
	driver.findElementById("com.theshaadi:id/btn_create_update").click();
    
    Thread.sleep(2000);
	
    // Write a message on post
    
    driver.findElementById("com.theshaadi:id/et_update_message").sendKeys("Weddings are important because they celebrate life and possibility.");
    driver.hideKeyboard();
    
    Thread.sleep(3000);
    driver.findElementById("com.theshaadi:id/iv_take_picture").click();
    driver.findElementById("android:id/text1").click();
    driver.findElementById("com.motorola.cameraone:id/preview_surface").click(); 
    //"com.sec.android.app.camera:id/save", "com.sec.android.app.camera:id/okay"
    driver.findElementById("com.motorola.cameraone:id/preview_surface").click();
    driver.hideKeyboard();
	
	}
	
	

}
