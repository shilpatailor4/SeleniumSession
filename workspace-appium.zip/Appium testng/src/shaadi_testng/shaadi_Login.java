package shaadi_testng;

import org.testng.annotations.Test;

import io.appium.java_client.MobileBy;

public class shaadi_Login extends shaadi_Home{
	
	@Test
    public static void login() throws InterruptedException {
    	
	
	 //If already login then direct open otherwise login application12
    
    
   	 boolean iselementnotpresent = driver.findElementsById("com.theshaadi:id/nav_open_img").size() ==0;
   	  
   	 if(iselementnotpresent)
   	 {
   		 //System.out.println("Success! Login Screen.");
   		 
   		 driver.findElementById("com.theshaadi:id/edtTxtUserName").sendKeys("9587089944");
   		 
   		driver.hideKeyboard();
            
            System.out.println("The number is enter 8619592802 ");
            
            driver.findElementById("com.theshaadi:id/cb").click();
            
            driver.findElementById("com.theshaadi:id/btn_login").click();
            
           
            
            //Handle pop up
            while (driver.findElements(MobileBy.id("com.android.packageinstaller:id/permission_allow_button")).size()>0) {
            	driver.findElement(MobileBy.id("com.android.packageinstaller:id/permission_allow_button")).click();
           	}
           //driver.findElementById("com.android.packageinstaller:id/permission_allow_button").click();
          //
            
           Thread.sleep(2000);
           
           System.out.println("Success! OTP screen.");
                       
           driver.findElementById("com.theshaadi:id/otp_et").sendKeys("2020");
            
           driver.findElementById("com.theshaadi:id/btn_submit_otp").click();
            
           System.out.println("The Shaadi app successfully login");
            
           Thread.sleep(3000);
            
   	 }
   	 
    }

    }
