package test.appium;


import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import org.openqa.selenium.interactions.touch.TouchActions;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.AppiumDriver;

import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;

import io.appium.java_client.touch.offset.PointOption;

public class appiumTestClass {
	
	static AppiumDriver<MobileElement> driver = null;
	
	public static MobileElement mobileElement;

	
public static void main(String[] args) throws InterruptedException, MalformedURLException {
		
	
		
		//Set the Desired Capabilities
		DesiredCapabilities caps = new DesiredCapabilities();
		caps.setCapability("deviceName", "My device");
		caps.setCapability("udid", "ZY223ZGH5D"); //Give Device ID of your mobile phone (adb devices)
		caps.setCapability("platformName", "Android");
		caps.setCapability("platformVersion", "7.0");
		caps.setCapability("appPackage", "com.theshaadi");
		caps.setCapability("appActivity", "com.theshaadi.splash.SplashActivity");    // App Activity of Shaadi App  com.theshaadi.splash.SplashActivity
		caps.setCapability("autoGrantPermission","true");
		caps.setCapability("noReset", "true");//Command to get App activity & package: (adb logcat) 
		//driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
	
		
		
		//Instantiate Appium Driver
		
		
		try {
			
		driver = new AndroidDriver<MobileElement>(new URL("http://127.0.0.1:4723/wd/hub"),caps);
		
		} catch (MalformedURLException e) {
			
			System.out.println(e.getMessage());

			}

          Thread.sleep(5000);
          
          //If already login then direct open otherwise login application
          
         if (driver!=null)
         {
        	 boolean iselementnotpresent = driver.findElementsById("com.theshaadi:id/nav_open_img").size() ==0;
        	 
        	 if(iselementnotpresent)
        	 {
        		 System.out.println("Login");
        		 
        		 driver.findElementById("com.theshaadi:id/edtTxtUserName").sendKeys("9587089944");
        		 
                 driver.hideKeyboard();
                 
                 System.out.println("The number is enter 9587089944");
                 
                 driver.findElementById("com.theshaadi:id/cb").click();
                 
                 driver.findElementById("com.theshaadi:id/btn_login").click();
                 
                System.out.println("step1");
                 
                 //Handle pop up
                 while (driver.findElements(MobileBy.id("com.android.packageinstaller:id/permission_allow_button")).size()>0) {
                	    driver.findElement(MobileBy.id("com.android.packageinstaller:id/permission_allow_button")).click();
                	}
                //driver.findElementById("com.android.packageinstaller:id/permission_allow_button").click();
               //
                 
                Thread.sleep(2000);
                            
                 driver.findElementById("com.theshaadi:id/otp_et").sendKeys("2020");
                 
                 driver.findElementById("com.theshaadi:id/btn_submit_otp").click();
                 
                 System.out.println("The Shaadi app successfully login");
                 
                 
        	 }
        	 
        	     
        //Timeline screen scrolled down
        	  
          Thread.sleep(5000);
          
         TouchAction action = new TouchAction(driver);
          action.press(PointOption.point(1010, 1166))//.waitAction()       scroll only particular space   
          .moveTo(PointOption.point(1010,1000))  //(1010,1000)
          .release()
          .perform();
          
          
          
          Thread.sleep(1500);
     
         /* // scrolled Up
          
          TouchAction action1 = new TouchAction(driver);
          action1.press(PointOption.point(1010, 1000))//.waitAction()       scroll only particular space   
          .moveTo(PointOption.point(1010,1166))  //(1010,1000)
          .release()
          .perform();
          
          Thread.sleep(1500);*/
          
       //Create a new post
          
          /*driver.findElementById("com.theshaadi:id/btn_create_update").click();
          
          Thread.sleep(2000);
          
          // Write a message on post
          
          driver.findElementById("com.theshaadi:id/et_update_message").sendKeys("Weddings are important because they celebrate life and possibility.");
          driver.hideKeyboard();
          
          Thread.sleep(2500);*/
          
          //....
          
          /*//Attach image on device gallery
          
          driver.findElementById("com.theshaadi:id/iv_take_picture").click();
          
        
          Thread.sleep(1500);
           
          driver.findElementById("android:id/text1").click();
          
        //Handle pop up
          while (driver.findElements(MobileBy.id("com.android.packageinstaller:id/permission_allow_button")).size()>0) {
         	    driver.findElement(MobileBy.id("com.android.packageinstaller:id/permission_allow_button")).click();
         	}
          
          
        Thread.sleep(2000);*/
          
          //Click on post create (done) button
          
        /*  driver.findElementById("com.theshaadi:id/iv_send_message").click();
          
          //screen scroll down to top
          
          Thread.sleep(1500);
        
        TouchAction action1 = new TouchAction(driver);
        action1.press(PointOption.point(865, 280))        
        .moveTo(PointOption.point(1010, 1166))
        .release()
        .perform();

      System.out.println("The post created successfully");*/
      
      Thread.sleep(2000);
      
      //Open side menu
      
      //driver.findElementById("com.theshaadi:id/nav_open_img").click();
      
      //Open My profile screen
      
     /* driver.findElementById("com.theshaadi:id/design_menu_item_text").click();
      System.out.println("Profile opened successfully");
      driver.navigate().back();*/
      
      
      Thread.sleep(3000);
      
      //Open Event timeline screen
      
      //driver.findElementById("com.theshaadi:id/nav_open_img").click();
      /*Thread.sleep(2000);
    driver.findElementById("com.theshaadi:id/richviewComment").click();
    System.out.println("Event Timeline");
    */
    
    
    
    /*//driver.findElementById("com.theshaadi:id/nav_open_img").click();
     //Thread.sleep(2000);
       driver.findElementById("com.theshaadi:id/tv_user_name").click();
       System.out.println("profile");*/
      
  
      /*//driver.findElementById("com.theshaadi:id/nav_open_img").click();
      //Thread.sleep(2000);
       driver.findElementById("com.theshaadi:id/textViewUserFullName").click();
       System.out.println("Bride & Groom family");*/
      
      
 /*    //Printing names of all the menus
  
      List<MobileElement> list = driver.findElementsById("com.theshaadi:id/design_menu_item_text");
      System.out.println("List size is " + list.size());
      System.out.println(list.get(0).getText());
      System.out.println(list.get(1).getText());
      System.out.println(list.get(2).getText());
      System.out.println(list.get(3).getText());
      System.out.println(list.get(4).getText());
      System.out.println(list.get(5).getText());
      System.out.println(list.get(6).getText());
      System.out.println(list.get(7).getText());
      System.out.println(list.get(8).getText());
      System.out.println(list.get(9).getText());
      System.out.println(list.get(10).getText());
      System.out.println(list.get(11).getText());
      
      (new TouchAction(driver))
       .press(PointOption.point(547, 1457))
       .moveTo(PointOption.point(547,0 ))
       .release()
       .perform();
      
      list = driver.findElementsById("com.theshaadi:id/design_menu_item_text");
      
      
      
      Thread.sleep(2000);
      
      TouchAction action1 = new TouchAction(driver);
      
      // Open profile screen
		System.out.println(list.get(1).getText());
		action1.tap(PointOption.point(230, 221)).perform();
		Thread.sleep(2000);
		driver.navigate().back();
		
	  // Open Timeline screen
		driver.findElementById("com.theshaadi:id/nav_open_img").click();
		System.out.println(list.get(2).getText());
		action1.tap(PointOption.point(262, 517)).perform();
		Thread.sleep(2000);
		
		
	  // Open Event Timeline screen
		driver.findElementById("com.theshaadi:id/nav_open_img").click();
		System.out.println(list.get(3).getText());
		action1.tap(PointOption.point(462, 597)).perform();
		Thread.sleep(2000);
		driver.navigate().back();
		
	  // Open Guest screen
		driver.findElementById("com.theshaadi:id/nav_open_img").click();
		System.out.println(list.get(4).getText());
		action1.tap(PointOption.point(216, 736)).perform();
		Thread.sleep(2000);
		driver.navigate().back();
		
	  // Open Bride & Groom family screen
		driver.findElementById("com.theshaadi:id/nav_open_img").click();
		System.out.println(list.get(5).getText());
		action1.tap(PointOption.point(251, 923)).perform();
		Thread.sleep(2000);
		driver.navigate().back();
		
	  // Open Local Attraction screen
		driver.findElementById("com.theshaadi:id/nav_open_img").click();
		System.out.println(list.get(6).getText());
		action1.tap(PointOption.point(336, 1024)).perform();
		Thread.sleep(2000);
		driver.navigate().back();
		
	  // Open Itinerary screen
		driver.findElementById("com.theshaadi:id/nav_open_img").click();
		System.out.println(list.get(7).getText());
		action1.tap(PointOption.point(375, 1194)).perform();
		Thread.sleep(2000);
		driver.navigate().back();
		
		
	 // Open Help Desk screen open 
		driver.findElementById("com.theshaadi:id/nav_open_img").click();
		System.out.println(list.get(8).getText());
		action1.tap(PointOption.point(295, 1333)).perform();
		Thread.sleep(2000);
		//driver.navigate().back();
		
		//Handle pop up
        while (driver.findElements(MobileBy.id("com.android.packageinstaller:id/permission_allow_button")).size()>0) {
       	    driver.findElement(MobileBy.id("com.android.packageinstaller:id/permission_allow_button")).click();
       	}
      
        driver.navigate().back();
        
     // Open Contact Us screen
		driver.findElementById("com.theshaadi:id/nav_open_img").click();
		System.out.println(list.get(9).getText());
		action1.tap(PointOption.point(262, 1476)).perform();
		Thread.sleep(2000);
		driver.navigate().back();
         
	  // Open Gallery screen
		driver.findElementById("com.theshaadi:id/nav_open_img").click();
		System.out.println(list.get(10).getText());
		action1.tap(PointOption.point(312, 1648)).perform();
		Thread.sleep(2000);
		driver.navigate().back();
		
	 // Open T&C screen
		driver.findElementById("com.theshaadi:id/nav_open_img").click();
		System.out.println(list.get(11).getText());
		action1.tap(PointOption.point(254, 1755)).perform();
		Thread.sleep(2000);
		driver.navigate().back(); 
      
     // logout application
		System.out.println(list.get(12).getText());
		action1.tap(PointOption.point(575, 1569)).perform();
		System.out.println("Successfully logout application");
		Thread.sleep(2000);
		   
	 */	
      
      // Timeline screen, like and comment and showing list of the like and comments
      
    	  /*driver.findElementById("com.theshaadi:id/ic_like_icn").click();
    	  System.out.println("The post liked");
          Thread.sleep(3000);*/
      
      if(driver.findElementById("com.theshaadi:id/ic_like_icn").isEnabled())
    	  
      {     	 
    	//driver.findElementById("com.theshaadi:id/ic_like_icn").click();
    	  System.out.println("true");
	  
    	  
    	        }
      else {
    	  System.out.println("false" );

      }
         
      
      Thread.sleep(3000);
      
      
      
      
     /* if(!driver.findElementById("com.theshaadi:id/textViewTotalLike").getText().equals("Like"))
      {
    	  driver.findElementById("com.theshaadi:id/textViewTotalLike").click();
    	  System.out.println("The post like listing screen opened");
    	  driver.navigate().back();
      }
      else {
    	  
    	  System.out.println("No people like this post");
      }
         
      
      Thread.sleep(3000);*/
      
      /*driver.findElementById("com.theshaadi:id/richviewComment").click();
      System.out.println("The comment screen is here");
      Thread.sleep(2000);
      driver.findElementById("com.theshaadi:id/et_comment_msg").sendKeys("Write a comment");
      driver.hideKeyboard();
      driver.findElementById("com.theshaadi:id/iv_comment_send").click();
      Thread.sleep(2500);
      
      driver.navigate().back();*/
      
      
      
      
      
          //System.out.println("Test successful");

      
}
         
}

}
