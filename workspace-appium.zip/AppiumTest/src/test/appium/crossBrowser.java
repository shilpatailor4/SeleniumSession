package test.appium;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;


public class crossBrowser {
	
	WebDriver driver;
	
	@Test
	@Parameters("browser")
    public void verifypageTitle(String browserName) throws InterruptedException {
		
		if(browserName.equalsIgnoreCase("firefox")) {
			
			System.setProperty("webdriver.gecko.driver","/home/shilpatailor/selenium Driver/geckodriver");
			driver = new FirefoxDriver();
			
		}
		
		else if(browserName.equalsIgnoreCase("chrome")) {
			
			System.setProperty("webdriver.chrome.driver","/home/shilpatailor/selenium Driver/chromedriver");
			driver = new ChromeDriver();
	}
		
		driver.manage().window().maximize();
		
		driver.get("https://webhonchoz.com/arabera/");
		
		System.out.println("Page Title is:" +driver.getTitle());
		
		Thread.sleep(3000);
		
		driver.quit();
	}
	

}
