package test.appium;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class theShaadiApp1 {
	
	WebDriver driver;
	
	@Test
	 public void setUp() throws Exception {

		//location of the app
		// File app = new File("/storage/emulated/0", "saadhilive.apk");
		 
		//To create an object of Desired Capabilities
		 DesiredCapabilities capability = new DesiredCapabilities();
		 
		//OS Name
		 capability.setCapability("device","Android");
		 capability.setCapability(CapabilityType.BROWSER_NAME, "");
		 
		//Mobile OS version. In My case its running on Android 7.0
		 capability.setCapability(CapabilityType.VERSION, "7.0");
		 //capability.setCapability("app", app.getAbsolutePath());
		 
		//To Setup the device name
		 capability.setCapability("deviceName","Redmi");
		 capability.setCapability("platformName","Android");
		 
		//set the package name of the app
		 capability.setCapability("app-package", "com.theshaadi");
		 
		//set the Launcher activity name of the app
		 capability.setCapability("app-activity", ".login.LoginActivity");
		 
		//driver object with new Url and Capabilities
		 //driver = new RemoteWebDriver(new URL(http://127.0.0.1:4723/wd/hub), capability);
		 AppiumDriver<MobileElement> driver = new AndroidDriver<MobileElement>(new URL("http://127.0.0.1:4723/wd/hub"), capability);
	
	
	}
		 public void testApp() throws MalformedURLException{
			 
			 System.out.println("App launched");
			 
			 // locate Add Contact button and click it
			 driver.findElement(By.className("android.widget.CheckBox")).click();
		 }
	}
  


	
	


