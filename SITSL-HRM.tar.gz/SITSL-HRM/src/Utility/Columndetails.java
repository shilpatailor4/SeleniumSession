package Utility;

public class Columndetails {
	public static final String URL = "http://partnerfortechnology.com/cherrynew";
	 //   public static final String Username = "demo@admin.com";
	  //  public static final String Password ="123456";
		public static final String Path_TestData ="/home/vikas/";
		public static final String File_TestData ="HRM.xls";
		
		//Test Data Sheet Columns
		public static final int Col_TestCaseName = 0;	
		public static final int Col_UserName =1 ;
		public static final int Col_Password = 2;
		public static final int Col_Browser = 3;
		public static final int Col_EmployeeType = 4;
		public static final int Col_SelectDepartment = 5;
		public static final int Col_NameofEmployee = 6;
		public static final int Col_DOB = 7;
		public static final int Col_Designation = 8;
	    public static final int Col_Gender = 9;
		public static final int Col_IsvalidforCL = 10;
		public static final int Col_HighestEducationalQualification = 11;
		public static final int Col_EmailId = 12;
		public static final int Col_PhoneNumber = 13;
		public static final int Col_CorrespondenceAddress = 14;
		public static final int Col_PermanentAddress = 15;
		public static final int Col_ProfilePicture = 16;
		public static final int Col_BasicSalary = 17;
		public static final int Col_QualificationStream = 18;
		public static final int Col_Result = 19;
		public static final int Col_Confirmemail = 20;
		public static final int Col_AlternatePhone = 21;
		public static final int Col_Work_Exp_Year = 22;
		public static final int Col_Work_Exp_Month = 23;
		public static final int Col_Current_Emp = 24;
		public static final int Col_Current_Compy = 25;
		public static final int Col_Current_CTC = 26;
		public static final int Col_Notice_Period = 27;
		public static final int Col_switch_job = 28;
		public static final int Col_Expected_CTC = 29;
		public static final int Col_Join_date = 30;
		public static final int Col_About_Self = 31;
		public static final int Col_FullName = 32;
		public static final int Col_location = 33;
				
		public static final String Path_ScreenShot = "/home/vikas/eclipse-workspace/SITSL-HRM/src/Screenshots/New folder/";
}
