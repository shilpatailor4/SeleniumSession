package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import Utility.Log;	


public class Workforce extends Base {

	 private static WebElement element = null;
	 
	 public Workforce (WebDriver driver)
	 {
	super(driver);
}
	 //Click on Workforce button from menu.
	 public static WebElement btn_workforce() throws Exception
     {
     	try {
     		 System.out.println("Click on menu");
element=driver.findElement(By.xpath("/html/body/section[2]/div[1]/div/div/div/div/div/ul/li[2]/a"));
     		 
     		Log.info("Click success on Workforce Menu");
     		
			} catch (Exception e) {
				Log.error("Click does not success on the Workforce Menu");
				throw(e);
			}
     return element;
     }

	 //Click on Add new Employee
public static WebElement btn_add_employee() throws Exception
{
	try {
		 System.out.println("Click on add new");
element=driver.findElement(By.xpath("//*[@id=\"btn_add_emp\"]"));
		 
		Log.info("Click success on Add New");
		
		} catch (Exception e) {
			Log.error("Click does not success on Add New Employee");
			throw(e);
		}
return element;
}

      //Fill Employee form :--select Employee_Type
public static WebElement dropdownlist_employee_type() throws Exception
{
	try {
		 
		element=driver.findElement(By.name("user_type")); // select Employee_Type
		 
		Log.info("Value select success");
		
		} catch (Exception e) {
			Log.error("Value does not select");
			throw(e);
		}
return element;
}

 //select department
	
		public static WebElement dropdownlist_employee_department() throws Exception
			{
	try {
		 
				element=driver.findElement(By.name("department")); // select department
		 
				Log.info("Value select success");
		
		} 		catch (Exception e) {
				Log.error("Value does not select");
				throw(e);
		}
					return element;
}

		
		// select DOB
		public static WebElement enter_employee_dob() throws Exception
		{
		try {

		element=driver.findElement(By.xpath("//*[@id=\"date\"]")); // select DOB
		//element= driver.findElement(By.cssSelector("ui-datepicker-calendar"));
		//element=driver.findElement(By.id("date"));
			
		Log.info("DOB select success");

		} 		catch (Exception e) {
		Log.error("DOB does not select");
		throw(e);
		}
			return element;
		}
		
		
		// select designation
public static WebElement dropdownlist_employee_designation() throws Exception
{
try {

	element=driver.findElement(By.name("designation")); // select designation

	Log.info("Value select success");

} 		catch (Exception e) {
	Log.error("Value does not select");
	throw(e);
}
		return element;
}



// Enter Name
public static WebElement enter_employee_FullName() throws Exception
{
try {

element=driver.findElement(By.xpath("/html/body/section[2]/div[3]/div/div/form/div[1]/div/div[1]/div[5]/div/input")); // Enetr Name

Log.info("Name Enter successfully");

} 		
catch (Exception e) {
Log.error("Name does not select");
throw(e);
}
	return element;
}

//Select Gender
public static WebElement select_gender() throws Exception
{
try {

element=driver.findElement(By.xpath("/html/body/section[2]/div[3]/div/div/form/div[1]/div/div[1]/div[7]/div[2]/div/label/span[1]")); // Select Gender

Log.info("Select Gender successfully");

} 		
catch (Exception e) {
Log.error("Gender does not select");
throw(e);
}
	return element;
}

//Select CL
public static WebElement select_CL() throws Exception
{
try {

element=driver.findElement(By.xpath("/html/body/section[2]/div[3]/div/div/form/div[1]/div/div[1]/div[8]/div[2]/div/label/span[1]")); // Select CL

Log.info("CL Select successfully");

} 		
catch (Exception e) {
Log.error("CL does not select");
throw(e);
}
	return element;
}


//Select Qualification
public static WebElement select_Qualification() throws Exception
{
try {

element=driver.findElement(By.name("qualification")); // Select Qualification

Log.info("Qualification Select successfully");

} 		
catch (Exception e) {
Log.error("Qualification does not select");
throw(e);
}
	return element;
}



//Select Qualification Stream
public static WebElement select_Qualification_Stream() throws Exception
{
try {

element=driver.findElement(By.xpath("//*[@id=\"edu_stream\"]")); // Select Qualification

Log.info("Qualification_Stream Select successfully");

} 		
catch (Exception e) {
Log.error("Qualification_Stream does not select");
throw(e);
}
	return element;
}

//Enetr Email
public static WebElement Enetr_Eamil() throws Exception
{
try {

element=driver.findElement(By.xpath("//*[@id=\"email_check\"]")); // Enter Email

Log.info("Email enter successfully");

} 		
catch (Exception e) {
Log.error("Email does not enter");
throw(e);
}
	return element;
}

//Enetr Phone no
public static WebElement Enetr_Phone() throws Exception
{
try {

element=driver.findElement(By.name("phone")); // Enter Phone

Log.info("Phone enter successfully");

} 		
catch (Exception e) {
Log.error("Phone does not enter");
throw(e);
}
	return element;
}





//Enetr Correspondence Address
public static WebElement Enetr_Corrsadd() throws Exception
{
try {

element=driver.findElement(By.name("correspondense_address")); // Enter correspondence_address

Log.info("Corres address enter successfully");

} 		
catch (Exception e) {
Log.error("Address does not enter");
throw(e);
}
	return element;
}

//Enetr Permanent Address
public static WebElement Enetr_Peradd() throws Exception
{
try {

element=driver.findElement(By.name("permanent_address")); // Enter permanent_address

Log.info("perm address enter successfully");

} 		
catch (Exception e) {
Log.error("Perm Address does not enter");
throw(e);
}
	return element;
}

//Browse Profile Pic
public static WebElement browse_image() throws Exception
{
try {

element=driver.findElement(By.xpath("//*[@id=\"picture\"]")); // Browse Profile pic

Log.info("Profile added successfully");

} 		
catch (Exception e) {
Log.error("Profile does not upload");
throw(e);
}
	return element;
}


//Enter Basic Salary
public static WebElement enetr_basic_salary() throws Exception
{
try {

element=driver.findElement(By.name("amount")); //Enter Basic Salary 

Log.info("Basic Salary Enetr successfully");

} 		
catch (Exception e) {
Log.error("Basic Salary does not enter");
throw(e);
}
	return element;
}


//Employee Save
public static WebElement employee_save() throws Exception
{
try {

element=driver.findElement(By.id("btn_insert")); // Employee Save

Log.info("Employee added successfully");

} 		
catch (Exception e) {
Log.error("Employee does not upload");
throw(e);
}
	return element;
}
}

