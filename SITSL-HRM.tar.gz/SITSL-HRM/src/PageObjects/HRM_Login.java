package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import Utility.Log;	


public class HRM_Login extends Base {

	 private static WebElement element = null;
     
     public HRM_Login(WebDriver driver){
         	super(driver);
     }     
     
     
    /* public static WebElement btn_signin() throws Exception
     {
     	try {
				element = driver.findElement(By.xpath("/html/body/section/div/div/main/div[2]/form[2]"));
     		Log.info("Click success on Login Page");
     		
			} catch (Exception e) {
				Log.error("Click does not success on the Login Page");
				throw(e);
			}
     return element;
     }
    */ 
     public static WebElement txtbx_UserName() throws Exception{
     	try{
	            element = driver.findElement(By.name("username"));
	            Log.info("Username text box is found on the Login Page");
     	}catch (Exception e){
        		Log.error("UserName text box is not found on the Login Page");
        		throw(e);
        		}
        	return element;
         }
     
     public static WebElement txtbx_Password() throws Exception{
     	try{
	        	element = driver.findElement(By.name("password"));
	            Log.info("Password text box is found on the Login page");
     	}catch (Exception e){
     		Log.error("Password text box is not found on the Login Page");
        		throw(e);
        		}
        	return element;
     }
     
     public static WebElement btn_LogIn() throws Exception{
     	try{
     		Thread.sleep(5000);
	        	element = driver.findElement(By.xpath("/html/body/section/div/div/div/div[2]/form/div/div/div/button"));
	            Log.info("LogIn button is found on the Login page");
     	}catch (Exception e){
     		Log.error("LogIn button is not found on the Login Page");
        		throw(e);
        		}
        	return element;
     }
	
}
