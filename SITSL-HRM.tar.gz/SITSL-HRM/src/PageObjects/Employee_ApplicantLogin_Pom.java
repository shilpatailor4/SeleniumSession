package PageObjects;

import org.apache.poi.ss.formula.functions.Value;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import Utility.Log;	

public class Employee_ApplicantLogin_Pom extends Base {
	
	private static WebElement element = null;
	
	public Employee_ApplicantLogin_Pom(WebDriver driver)
			{
		super(driver);}
	
	
	//Login Applicant
	//Enter Applicant Email
	public static WebElement Applicant_Email() throws Exception
	{
		try {
			System.out.println("Applicant Email");
			element = driver.findElement(By.name("email"));
			Log.info("Enter Success Email");

		} catch (Exception e) {
			Log.error("Does not Enetr Email");
			throw(e);
		}
		return element;
	}
	
	//Enter Applicant Phone no
		public static WebElement Applicant_Phone() throws Exception
		{
			try {
				System.out.println("Applicant Phone");
				element = driver.findElement(By.name("phonenumber"));
				Log.info("Enter Success Phoneno");

			} catch (Exception e) {
				Log.error("Does not Enetr Phoneno");
				throw(e);
			}
			return element;
		}
		
		
		// Login by Applicant
		public static WebElement Applicant_Login() throws Exception
		{
			try {
				System.out.println("Applicant Login");
				element = driver.findElement(By.name("login"));
				Log.info("Login Success");

			} catch (Exception e) {
				Log.error(" Login Does not success");
				throw(e);
			}
			return element;
					
		}	
		
		
		}
	

