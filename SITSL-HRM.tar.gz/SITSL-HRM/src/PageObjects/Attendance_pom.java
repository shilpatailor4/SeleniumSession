package PageObjects;



import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import Utility.Log;	


public class Attendance_pom extends Base {

	 private static WebElement element = null;
	 
	 public Attendance_pom(WebDriver driver)
	 {
	 super(driver);
	 }

	 //Click on Attendance from
	 public static WebElement btn_Attendance_dash() throws Exception
     {
     	try {
     		 System.out.println("Click on Dash_attendance");
element=driver.findElement(By.xpath("/html/body/section[2]/div[2]/div/div[3]/div[2]/div/a/div[1]"));
     		 
     		Log.info("Click success on Dash_Attendance");
     		
			} catch (Exception e) {
				Log.error("Click does not success on the Dash_Attendance");
				throw(e);
			}
     return element;
     }


	//Fill the Attendance of today date
		 public static WebElement Fill_Attendance() throws Exception
	     {
	     	try {
	     		 System.out.println("Click on Present");
	element=driver.findElement(By.xpath("/html/body/section[2]/div[2]/div/div[4]/div/div/form/div[1]/table/tbody/tr[1]/td[5]/label[1]"));
	     		 
	     		Log.info("Click success on Present");
	     		
				} catch (Exception e) {
					Log.error("Click does not success on Present");
					throw(e);
				}
	     return element;
	     }


		//Submit Attendance of today date
		 public static WebElement Submit_Attendance() throws Exception
	     {
	     	try {
	     		 System.out.println("Click on Update Attendance");
	element=driver.findElement(By.xpath("//*[@id=\"submit\"]"));
	     		 
	     		Log.info("Click success on Present");
	     		
				} catch (Exception e) {
					Log.error("Click does not success on Update Attendance");
					throw(e);
				}
	     return element;
	     }

}