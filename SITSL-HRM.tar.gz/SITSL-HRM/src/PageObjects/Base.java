package PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Base {
	public static WebDriver driver;
	public static boolean bResult;
	
	public  Base(WebDriver driver){
		
		Base.driver = driver;
		Base.bResult = true;
	}
}
