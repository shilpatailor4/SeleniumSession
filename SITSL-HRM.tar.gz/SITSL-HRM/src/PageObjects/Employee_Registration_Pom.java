package PageObjects;



import java.util.List;
import org.apache.poi.ss.formula.functions.Value;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import Utility.Log;	


public class Employee_Registration_Pom extends Base {

	private static WebElement element = null;

	public Employee_Registration_Pom(WebDriver driver )

	{
		super(driver);

	}

	//Click on Registration Form
	public static WebElement btn_Registration() throws Exception
	{
		try {
			System.out.println("Click on Registration");
			element=driver.findElement(By.xpath("/html/body/section/div/div/main/div[2]/form[1]/a/div/img"));

			Log.info("Click success on Registration Form");

		} catch (Exception e) {
			Log.error("Click does not success on the Registration Form");
			throw(e);
		}
		return element;
	}

	//Enter Full Name
	public static WebElement Employee_FullName() throws Exception
	{
		try {
			System.out.println("FullName");
			element=driver.findElement(By.name("fullname"));

			Log.info("Enter success FullName");

		} catch (Exception e) {
			Log.error("Does not Enetr FullName");
			throw(e);
		}
		return element;
	}

	//Select Gender male
	public static WebElement Employee_GenderM() throws Exception
	{
		try {
			System.out.println("Gender");
			 element= driver.findElement(By.xpath("/html/body/section/div/div/div/div/div/div/form/div[1]/div[2]/div/label[2]/span[1]"));
		
			Log.info("Enter success gender");

		} catch (Exception e) {
			Log.error("Does not Enetr Gender");
			throw(e);
		}
		return element;
	}

	//Select Gender Female
		public static WebElement Employee_GenderF() throws Exception
		{
			try {
				System.out.println("Gender");
				 element= driver.findElement(By.xpath("/html/body/section/div/div/div/div/div/div/form/div[1]/div[2]/div/label[3]/span[1]"));
			
				Log.info("Enter success gender");

			} catch (Exception e) {
				Log.error("Does not Enetr Gender");
				throw(e);
			}
			return element;
		}

		//Select Gender Other
				public static WebElement Employee_GenderO() throws Exception
				{
					try {
						System.out.println("Gender");
						 element= driver.findElement(By.xpath("/html/body/section/div/div/div/div/div/div/form/div[1]/div[2]/div/label[4]/span[1]"));
					
						Log.info("Enter success gender");

					} catch (Exception e) {
						Log.error("Does not Enetr Gender");
						throw(e);
					}
					return element;
				}
				
				//Select locationsetup
				public static WebElement Employee_locationsetup() throws Exception
				{
					try {
						System.out.println("Location");
						element=driver.findElement(By.name("locationsetup"));

						Log.info("Enter success Location");

					} catch (Exception e) {
						Log.error("Does not Enetr Location");
						throw(e);
					}
					return element;
				}
												
				
				
	//Select Department
	public static WebElement Employee_department() throws Exception
	{
		try {
			System.out.println("Department");
			element=driver.findElement(By.name("department"));

			Log.info("Enter success Department");

		} catch (Exception e) {
			Log.error("Does not Enetr department");
			throw(e);
		}
		return element;
	}


	//Select Designation 
	public static WebElement Employee_designation() throws Exception
	{
		try {
			System.out.println("Designation");
			element=driver.findElement(By.name("designation"));

			Log.info("Enter success designation");

		} catch (Exception e) {
			Log.error("Does not Enetr designation");
			throw(e);
		}
		return element;
	}

	//Select Qualification 
	public static WebElement Employee_qualification() throws Exception
	{
		try {
			System.out.println("Qualification");
			element=driver.findElement(By.name("qualification"));

			Log.info("Enter success qualification");

		} catch (Exception e) {
			Log.error("Does not Enetr qualification");
			throw(e);
		}
		return element;
	}

	//Select Stream 
	public static WebElement Employee_stream() throws Exception
	{
		try {
			System.out.println("Stream");
			element=driver.findElement(By.name("stream"));

			Log.info("Enter success stream");

		} catch (Exception e) {
			Log.error("Does not Enetr stream");
			throw(e);
		}
		return element;

	}


	//Enter DOB
	public static WebElement Employee_dob() throws Exception
	{
		try {
			System.out.println("DOB");
			element=driver.findElement(By.name("dob"));

			Log.info("Enter success DOB");

		} catch (Exception e) {
			Log.error("Does not Enetr DOB");
			throw(e);
		}
		return element;

	}
	
	//Enter DOB
		public static WebElement Employee_dob1() throws Exception
		{
			try {
				System.out.println("DOB");
				element=driver.findElement(By.xpath("/html/body/div[2]/table/tbody/tr[1]/td[7]/a"));

				Log.info("Enter success DOB");

			} catch (Exception e) {
				Log.error("Does not Enetr DOB");
				throw(e);
			}
			return element;

		}
	
	
		//Enter Email
	public static WebElement Employee_email() throws Exception
	{
		try {
			System.out.println("Email");
			element=driver.findElement(By.name("email"));

			Log.info("Enter success email");

		} catch (Exception e) {
			Log.error("Does not Enetr email");
			throw(e);
		}
		return element;

	}


	//Enter Confirm Email Id
	public static WebElement Employee_confirmemail() throws Exception
	{
		try {
			System.out.println("Confirm Email");
			element=driver.findElement(By.name("confirm_email"));

			Log.info("Enter success confirm_email");

		} catch (Exception e) {
			Log.error("Does not Enetr confirm_email");
			throw(e);
		}
		return element;

	}

	//Enter Phone No.
	public static WebElement Employee_Phone() throws Exception
	{
		try {
			System.out.println("Phone No.");
			element=driver.findElement(By.name("phonenumber"));

			Log.info("Enter success phonenumber");

		} catch (Exception e) {
			Log.error("Does not Enetr phonenumber");
			throw(e);
		}
		return element;

	}


	//Enter Alternate Phone No.
	public static WebElement Employee_AlternatePhone() throws Exception
	{
		try {
			System.out.println("Alternate No.");
			element=driver.findElement(By.name("alternate_phone"));

			Log.info("Enter success alternate_phone");

		} catch (Exception e) {
			Log.error("Does not Enetr alternate_phone");
			throw(e);
		}
		return element;

	}


	//Enter Correspondence Address 
	public static WebElement Employee_CA() throws Exception
	{
		try {
			System.out.println("Correspondence Address .");
			element=driver.findElement(By.name("correspondense_address"));

			Log.info("Enter success correspondense_address");

		} catch (Exception e) {
			Log.error("Does not Enetr correspondense_address");
			throw(e);
		}
		return element;

	}


	//Enter Same Address 
	public static WebElement Employee_Same_Address() throws Exception
	{
		try {
			System.out.println("Click on Same Address");
			element=driver.findElement(By.id("filltoo"));

			Log.info("Enter success Same Address");

		} catch (Exception e) {
			Log.error("Does not Enetr Same Address");
			throw(e);
		}
		return element;

	}

	//Enter Permanent Address
	public static WebElement Employee_PA() throws Exception
	{
		try {
			System.out.println("Permanent Address");
			element=driver.findElement(By.name("permanent_address"));

			Log.info("Enter success permanent_address");

		} catch (Exception e) {
			Log.error("Does not Enetr permanent_address");
			throw(e);
		}
		return element;

	}



	//Enter Work Experience in Years
	public static WebElement Employee_workexp() throws Exception
	{
		try {
			System.out.println("Work Experience in Years");
			element=driver.findElement(By.name("exp_year"));

			Log.info("Enter success Work Experience in Years");

		} catch (Exception e) {
			Log.error("Does not Enetr Work Experience in Years");
			throw(e);
		}
		return element;

	} 	



	//Enter Work Experience in Months
	public static WebElement Employee_workexpmonth() throws Exception
	{
		try {
			System.out.println("Work Experience in Month");
			element=driver.findElement(By.name("exp_month"));

			Log.info("Enter success Work Experience in exp_month");

		} catch (Exception e) {
			Log.error("Does not Enetr Work Experience in exp_month");
			throw(e);
		}
		return element;

	} 	

	//Enter Current Employer
	public static WebElement Employee_Employer() throws Exception
	{
		try {
			System.out.println("Current Employer");
			element=driver.findElement(By.xpath("/html/body/section/div/div/div/div/div/div/form/div[4]/div[2]/div"));

			Log.info("Enter success Current Employer");

		} catch (Exception e) {
			Log.error("Does not Enetr Current Employer");
			throw(e);
		}
		return element;

	} 	


	//Current Company
	public static WebElement Employee_currentcompany() throws Exception
	{
		try {
			System.out.println("Current Company");
			element=driver.findElement(By.name("current_company"));

			Log.info("Enter success Current Company");

		} catch (Exception e) {
			Log.error("Does not Enetr Current Company");
			throw(e);
		}
		return element;

	} 					 


	//Current CTC
	public static WebElement Employee_ctc() throws Exception
	{
		try {
			System.out.println("Current CTC");
			element=driver.findElement(By.name("current_ctc"));

			Log.info("Enter success Current CTC");

		} catch (Exception e) {
			Log.error("Does not Enetr Current CTC");
			throw(e);
		}
		return element;

	} 

	//Notice period at current firm
	public static WebElement Employee_noticeperiod() throws Exception
	{
		try {
			System.out.println("Notice period ");
			element=driver.findElement(By.name("notice_period"));

			Log.info("Enter success Notice period");

		} catch (Exception e) {
			Log.error("Does not Enetr Notice period");
			throw(e);
		}
		return element;

	}  

	//Why do you wish to switch your job?
	public static WebElement Employee_switchjob() throws Exception
	{
		try {
			System.out.println("switch your job");
			element=driver.findElement(By.name("why_switch"));

			Log.info("Enter success switch your job");

		} catch (Exception e) {
			Log.error("Does not Enetr switch your job");
			throw(e);
		}
		return element;

	}  


	//Expected CTC
	public static WebElement Employee_Exctc() throws Exception
	{
		try {
			System.out.println("Expected CTC");
			element=driver.findElement(By.name("expected_ctc"));

			Log.info("Enter success Expected CTC");

		} catch (Exception e) {
			Log.error("Does not Enetr Expected CTC");
			throw(e);
		}
		return element;

	} 


	//join in days
	public static WebElement Employee_Joindate() throws Exception
	{
		try {
			System.out.println("join in days");
			element=driver.findElement(By.name("time_to_join"));

			Log.info("Enter success join in days");

		} catch (Exception e) {
			Log.error("Does not Enetr join in days");
			throw(e);
		}
		return element;

	} 

	//About your self
	public static WebElement Employee_About_self() throws Exception
	{
		try {
			System.out.println("About your self");
			element=driver.findElement(By.name("feedback"));

			Log.info("Enter success About your self");

		} catch (Exception e) {
			Log.error("Does not Enetr About your self");
			throw(e);
		}
		return element;

	} 



	//Save register
	public static WebElement Employee_Save_Register () throws Exception
	{
		try {
			System.out.println("Registration Save");
			element=driver.findElement(By.name("btn_save_reg"));

			Log.info("Registration Save Successfully");

		} catch (Exception e) {
			Log.error("Does not save Registration");
			throw(e);
		}
		return element;

	} 

}
