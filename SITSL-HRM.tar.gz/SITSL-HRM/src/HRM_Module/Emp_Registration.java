package HRM_Module;

import javax.lang.model.element.Element;

import org.apache.poi.ss.formula.functions.Value;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Reporter;
import org.testng.annotations.Test;
import PageObjects.Workforce;
import PageObjects.Employee_Registration_Pom;
import PageObjects.HRM_Login;
import HRM_Module.HRM_Login_Action;
import Utility.Columndetails;
import Utility.ExcelUtils;
import Utility.Log;
import org.openqa.selenium.Alert;

public class Emp_Registration {


	//public static WebElement driver;
	public static WebDriver driver;

	public static void Execute(int iTestCaseRow) throws Exception{

		//Click on Registration form
		Employee_Registration_Pom.btn_Registration().click();
		System.out.println("Click on Registration form");
		Log.info("Click action is performed on Registration");


		//Enter Full name of employee
		try {
			String fullname= ExcelUtils.getCellData(iTestCaseRow, Columndetails.Col_FullName);
			System.out.println("Name :" + fullname);
			Employee_Registration_Pom.Employee_FullName().sendKeys(fullname);
			Log.info( "Name Enter Successfully" );
		} catch (Exception e) {
			Log.error("Name does not added");
			throw(e);
		}

		//Enter Gender of employee
		try {
			String gender= ExcelUtils.getCellData(iTestCaseRow, Columndetails.Col_Gender);
			System.out.println("Gender is:" + gender);
			if(ExcelUtils.getCellData(iTestCaseRow, Columndetails.Col_Gender).equals(gender))
			{
				Employee_Registration_Pom.Employee_GenderF().click();
			}
			else{
				Employee_Registration_Pom.Employee_GenderO().click();
			}
			/*if(geM.isSelected())
			{
				System.out.println("Check 1" + geM);
				geM.click();
			}*/

			//Employee_Registration_Pom.Employee_GenderF().click();
			/*	if(geF.isSelected())
			{
				System.out.println("Check 2" + geF);
				geF.click();
			}

			WebElement geO = Employee_Registration_Pom.Employee_GenderO();


			if(geO.equals(gender))
			{
				geO.click();
			}
			 */		
			Log.info( "Gender Enter Successfully" );
		} catch (Exception e) {
			Log.error("Gender does not added");
			throw(e);
		}

		//Select employee location 
		try {
			String loc= ExcelUtils.getCellData(iTestCaseRow, Columndetails.Col_location);
			System.out.println("Department:" + loc);
			Select oselect =  new Select(Employee_Registration_Pom.Employee_locationsetup());
			oselect.selectByVisibleText(loc);
			Log.info( "Job location select Successfully" );
		} catch (Exception e) {
			Log.error("Location does not select");
			throw(e);
		}





		//Select Department of employee
		try {
			String dep= ExcelUtils.getCellData(iTestCaseRow, Columndetails.Col_SelectDepartment);
			System.out.println("Department:" + dep);
			Select oselect =  new Select(Employee_Registration_Pom.Employee_department());
			oselect.selectByVisibleText(dep);
			Log.info( "Department select Successfully" );
		} catch (Exception e) {
			Log.error("Department does not select");
			throw(e);
		}

		//Select Designation of employee
		try {
			String desig= ExcelUtils.getCellData(iTestCaseRow, Columndetails.Col_Designation);
			System.out.println("Designation:" + desig);
			Select oselect =  new Select(Employee_Registration_Pom.Employee_designation());
			oselect.selectByVisibleText(desig);
			Log.info( "Designation select Successfully" );
		} catch (Exception e) {
			Log.error("Designation does not select");
			throw(e);
		}


		//Enter DOB
		try {

			String dob1= ExcelUtils.getCellData(iTestCaseRow, Columndetails.Col_DOB);
			System.out.println("DOB is:" + dob1);
			Employee_Registration_Pom.Employee_dob().click();
			//Employee_Registration_Pom.Employee_dob().sendKeys(dob1);
			Employee_Registration_Pom.Employee_dob1().click();
			Log.info( "DOB Enter Successfully" );
		} catch (Exception e) {
			Log.error("DOB does not added");
			throw(e);
		}

		/*driver.findElement(By.xpath("//*[@id=\"dp1535689605155\"]"));
        WebElement dateWidget = driver.findElement(By.xpath("/html/body/div[2]/table"));
		Thread.sleep(5000);

        List<WebElement> rows=dateWidget.findElements(By.tagName("tr"));
        List<WebElement> columns=dateWidget.findElements(By.tagName("td"));
        for (WebElement cell: columns){
               //Select 28th Date 
               if (cell.getText().equals("1")){
                  // cell.findElement(By.linkText("28")).click();
            	   cell.click();
               break;
               }
              }*/




		//Select Qualification of employee
		try {
			String Quali= ExcelUtils.getCellData(iTestCaseRow, Columndetails.Col_HighestEducationalQualification);
			System.out.println("Qualification:" + Quali);
			Select oselect =  new Select(Employee_Registration_Pom.Employee_qualification());
			oselect.selectByVisibleText(Quali);
			Log.info( "Qualification select Successfully" );
		} catch (Exception e) {
			Log.error("Qualification does not select");
			throw(e);
		}

		//Select Qualification Stream of employee
		try {
			String stream= ExcelUtils.getCellData(iTestCaseRow, Columndetails.Col_QualificationStream);
			System.out.println("Stream:" + stream);
			Select oselect =  new Select(Employee_Registration_Pom.Employee_stream());
			oselect.selectByVisibleText(stream);
			Log.info( "QualificationStream select Successfully" );
		} catch (Exception e) {
			Log.error("QualificationStream does not select");
			throw(e);
		}

		//Email of employee
		try {
			String email= ExcelUtils.getCellData(iTestCaseRow, Columndetails.Col_EmailId);
			System.out.println("Email:" + email);
			Employee_Registration_Pom.Employee_email().sendKeys(email);
			Log.info( "Email enter Successfully" );
		} catch (Exception e) {
			Log.error("Email does not Add");
			throw(e);
		}	

		// Confirm Email of employee
		try {
			String confemail= ExcelUtils.getCellData(iTestCaseRow, Columndetails.Col_Confirmemail);
			System.out.println("Confirm Email:" + confemail);
			Employee_Registration_Pom.Employee_confirmemail().sendKeys(confemail);
			Log.info( "ConfirmEmail enter Successfully" );
		} catch (Exception e) {
			Log.error("ConfirmEmail does not Add");
			throw(e);
		}	

		// Phone No of employee
		try {
			String phone= ExcelUtils.getCellData(iTestCaseRow, Columndetails.Col_PhoneNumber);
			System.out.println("Phone:" + phone);
			Employee_Registration_Pom.Employee_Phone().sendKeys(phone);
			Log.info( "Phone no enter Successfully" );
		} catch (Exception e) {
			Log.error("Phone no does not Add");
			throw(e);
		}

		// Alternate Phone No of employee
		try {
			String Alphone= ExcelUtils.getCellData(iTestCaseRow, Columndetails.Col_AlternatePhone);
			System.out.println("Alternate:" + Alphone);
			Employee_Registration_Pom.Employee_AlternatePhone().sendKeys(Alphone);
			Log.info( "AlternatePhone no enter Successfully" );
		} catch (Exception e) {
			Log.error("AlternatePhone no does not Add");
			throw(e);
		}

		// Enter Correspondence  address of employee
		try {
			String coadd= ExcelUtils.getCellData(iTestCaseRow, Columndetails.Col_CorrespondenceAddress);
			System.out.println("Correspondence:" + coadd);
			Employee_Registration_Pom.Employee_CA().sendKeys(coadd);
			Log.info( "Correspondence address enter Successfully" );
		} catch (Exception e) {
			Log.error("Correspondence address does not Add");
			throw(e);
		}

		// Enter Same as address of employee
		try {
			Employee_Registration_Pom.Employee_Same_Address().click();
			Log.info( "Same address Click Successfully" );
		} catch (Exception e) {
			Log.error("Same address does not Add");
			throw(e);
		}

		// Enter Permanent address of employee
		try {
			String peradd= ExcelUtils.getCellData(iTestCaseRow, Columndetails.Col_PermanentAddress);
			System.out.println("Permanent :" + peradd);
			Employee_Registration_Pom.Employee_PA().sendKeys(peradd);
			Log.info( "Permanent address enter Successfully" );
		} catch (Exception e) {
			Log.error("Permanent address does not Add");
			throw(e);
		}

		// Enter Work Experience in Years of employee
		try {
			String wkexpyear= ExcelUtils.getCellData(iTestCaseRow, Columndetails.Col_Work_Exp_Year);
			System.out.println("Work Experience in Year:" + wkexpyear);
			Employee_Registration_Pom.Employee_workexp().sendKeys(wkexpyear);
			Log.info( "Work Experience in Years enter Successfully" );
		} catch (Exception e) {
			Log.error("Work Experience in Years does not Add");
			throw(e);
		}

		// Enter Work Experience in Month of employee
		try {
			String wkexpmnt= ExcelUtils.getCellData(iTestCaseRow, Columndetails.Col_Work_Exp_Month);
			System.out.println("Work Experience in Month:" + wkexpmnt);
			Employee_Registration_Pom.Employee_workexpmonth().sendKeys(wkexpmnt);
			Log.info( "Work Experience in Month enter Successfully" );
		} catch (Exception e) {
			Log.error("Work Experience in Month does not Add");
			throw(e);
		}

		// Enter Current Employee of Company
		try {
			String Crtemp= ExcelUtils.getCellData(iTestCaseRow, Columndetails.Col_Current_Emp);
			System.out.println("Current Employee:" + Crtemp);
			Employee_Registration_Pom.Employee_Employer().click();
			Log.info( "Current Employee click Successfully" );
		} catch (Exception e) {
			Log.error("Current Employee does not Click");
			throw(e);
		}

		// Enter Current Company Name
		try {
			String Crtcmp= ExcelUtils.getCellData(iTestCaseRow, Columndetails.Col_Current_Compy);
			System.out.println("Current Company:" + Crtcmp);
			Employee_Registration_Pom.Employee_currentcompany().sendKeys(Crtcmp);
			Log.info( "Current Company added Successfully" );
		} catch (Exception e) {
			Log.error("Current Company  does not Add");
			throw(e);
		}

		// Enter Current CTC 
		try {
			String ctc= ExcelUtils.getCellData(iTestCaseRow, Columndetails.Col_Current_CTC);
			System.out.println("Current CTC:" + ctc);
			Employee_Registration_Pom.Employee_ctc().sendKeys(ctc);
			Log.info( "Current CTC added Successfully" );
		} catch (Exception e) {
			Log.error("Current CTC does not Add");
			throw(e);
		}
		// Enter Notice period at current firm
		try {
			String noticetime= ExcelUtils.getCellData(iTestCaseRow, Columndetails.Col_Notice_Period);
			System.out.println("Notice period:" + noticetime);
			Employee_Registration_Pom.Employee_noticeperiod().sendKeys(noticetime);
			Log.info( "Notice period added Successfully" );
		} catch (Exception e) {
			Log.error("Notice period does not Add");
			throw(e);
		}

		// Enter switch your job?
		try {
			String swth= ExcelUtils.getCellData(iTestCaseRow, Columndetails.Col_switch_job);
			System.out.println("switch your job:" + swth);
			Employee_Registration_Pom.Employee_switchjob().sendKeys(swth);
			Log.info( "switch job added Successfully" );
		} catch (Exception e) {
			Log.error("switch_job does not Add");
			throw(e);
		}

		// Enter Expected CTC 
		try {
			String exctc= ExcelUtils.getCellData(iTestCaseRow, Columndetails.Col_Expected_CTC);
			System.out.println("Expected CTC:" + exctc);
			Employee_Registration_Pom.Employee_Exctc().sendKeys(exctc);
			Log.info( " Expected CTC added Successfully" );
		} catch (Exception e) {
			Log.error("Expected CTC does not Add");
			throw(e);
		}

		// Enter Time required to join in days
		try {
			String join= ExcelUtils.getCellData(iTestCaseRow, Columndetails.Col_Join_date);
			System.out.println("join in days:" + join);
			Employee_Registration_Pom.Employee_Joindate().sendKeys(join);
			Log.info( "Join_date added Successfully" );
		} catch (Exception e) {
			Log.error("Join_date does not Add");
			throw(e);
		}

		// Enter About Your Self 
		try {
			String self= ExcelUtils.getCellData(iTestCaseRow, Columndetails.Col_About_Self);
			System.out.println("About Your Self:" + self);
			Employee_Registration_Pom.Employee_About_self().sendKeys(self);
			Log.info( "About your self added Successfully" );
		} catch (Exception e) {
			Log.error("About your self does not Add");
			throw(e);
		}

		// Save Registration form
		try
		{
			Employee_Registration_Pom.Employee_Save_Register().click();
			Thread.sleep(5000);
			System.out.println("Registration save successfully");
			System.out.println("Popup 1" + driver.switchTo().alert().getText());	
			driver.switchTo().alert().accept();
			Thread.sleep(5000);
			System.out.println("Popup click");
			Log.info("Registration save successfully");
		} catch (Exception e) {
			Log.error("Registration does not Save");
			throw(e);
		}

		// Switching to Alert        
		/*try {

			driver.switchTo().alert().accept();
			 System.out.println("Popup click");
			Thread.sleep(5000);
			// Capturing alert message.    
			//String alertMessage= driver.switchTo().alert().getText();		

			// Displaying alert message

      //System.out.println(alertMessage);	


			// Accepting alert		
			//alert.accept();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		*/
	} 
}
