package HRM_Module;

import org.openqa.selenium.support.ui.Select;
import org.testng.Reporter;
import org.testng.annotations.Test;

import PageObjects.Attendance_pom;
import PageObjects.HRM_Login;
import HRM_Module.HRM_Login_Action;
import Utility.Columndetails;
import Utility.ExcelUtils;
import Utility.Log;

public class Employee_Attendance {
	
	
	public static void Execute(int iTestCaseRow) throws Exception{

     //Click on Attendance from Dashboard
		Attendance_pom.btn_Attendance_dash().click();
		Thread.sleep(5000);
	     System.out.println("Click on Attendance");
	Log.info("Click action is performed on Dashboard_Attendance ");
		

	//Click on Present Radio button
	Attendance_pom.Fill_Attendance().click();
	 System.out.println("Click on Present radio button");
		Log.info("Click action is performed on Present radio button");
		
		//Click on Update Attendance 
		Attendance_pom.Submit_Attendance().click();
		 System.out.println("Click on Save Attendance");
			Log.info("Click action is performed on Submit Attendance");
		
	
}
}