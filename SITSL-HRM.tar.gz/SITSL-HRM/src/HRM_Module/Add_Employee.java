package HRM_Module;

import org.openqa.selenium.support.ui.Select;
import org.testng.Reporter;
import org.testng.annotations.Test;
import PageObjects.Workforce;
import PageObjects.HRM_Login;
import HRM_Module.HRM_Login_Action;
import Utility.Columndetails;
import Utility.ExcelUtils;
import Utility.Log;




public class Add_Employee{


 public static void Execute(int iTestCaseRow) throws Exception{
	 //Click on Workfore from menu
	 Workforce.btn_workforce().click();
		 Thread.sleep(5000);
	     System.out.println("Click on workforce");
	Log.info("Click action is performed on workforce");

		 
		 
		 //Click on add new employee
		 Workforce.btn_add_employee().click();
		 Thread.sleep(5000);
	     System.out.println("Click on Add New");
	Log.info("Click action is performed on Add New");

	
	//Select Employee type from dropdown list
	
	 try {
     	String dropdown= ExcelUtils.getCellData(iTestCaseRow, Columndetails.Col_EmployeeType);
         System.out.println("Select value is:" + dropdown);
         Select oselect =  new Select(Workforce.dropdownlist_employee_type());
         oselect.selectByVisibleText(dropdown);
 
         Log.info( "Item is added Successfully" );
		} catch (Exception e) {
			Log.error("Item is not added");
			throw(e);
						}
	 
	 

	//Enter DOB
	try {
		String dob1= ExcelUtils.getCellData(iTestCaseRow, Columndetails.Col_DOB);
	System.out.println("DOB is:" + dob1);
	 Thread.sleep(5000);
	 Workforce.enter_employee_dob().sendKeys(dob1);
	//Workforce.enter_employee_dob().click();
	 
	 Log.info( "DOB is added Successfully" );
		} catch (Exception e) {
			Log.error("DOB is not added");
			throw(e);
			
						}
	 
	 
	 
	 
	 
	 
//Select Employee department from dropdown list
try {
 	String dropdown= ExcelUtils.getCellData(iTestCaseRow, Columndetails.Col_SelectDepartment);
     System.out.println("Select value is:" + dropdown);
     Select oselect =  new Select(Workforce.dropdownlist_employee_department());
     oselect.selectByVisibleText(dropdown);

     Log.info( "Item is added Successfully" );
	} catch (Exception e) {
		Log.error("Item is not added");
		throw(e);
					}


//Select Employee designation from dropdown list
try {
	String dropdown= ExcelUtils.getCellData(iTestCaseRow, Columndetails.Col_Designation);
   System.out.println("Select value is:" + dropdown);
   Select oselect =  new Select(Workforce.dropdownlist_employee_designation());
   oselect.selectByVisibleText(dropdown);

   Log.info( "Item is added Successfully" );
	} catch (Exception e) {
		Log.error("Item is not added");
		throw(e);
					}

	 


	
//Enter Name
try {
	String nameofemployee= ExcelUtils.getCellData(iTestCaseRow, Columndetails.Col_NameofEmployee);
	System.out.println ("user name is :" + nameofemployee);
     Workforce.enter_employee_FullName().sendKeys(nameofemployee);
	
Log.info( "Name is added Successfully" );
	} catch (Exception e) {
		Log.error("Name does not add");
		throw(e);
					}


//Select Gender
try {
	String gender= ExcelUtils.getCellData(iTestCaseRow, Columndetails.Col_Gender);
	System.out.println ("Gender name is :" + gender);
   Workforce.select_gender().click();
	
Log.info( "Gender select Successfully" );
	} catch (Exception e) {
		Log.error("Gender does not add");
		throw(e);
					}


//Select CL
try {
	String CL= ExcelUtils.getCellData(iTestCaseRow, Columndetails.Col_IsvalidforCL);
	System.out.println ("IsValidfor CL is :" + CL);
 Workforce.select_CL().click();
	
Log.info( "CL select Successfully" );
	} catch (Exception e) {
		Log.error("CL does not add");
		throw(e);
	
	}


//Enter  qualification
try {
	String qali= ExcelUtils.getCellData(iTestCaseRow, Columndetails.Col_HighestEducationalQualification);
	System.out.println ("Qualification name is :" + qali);
	Select oselect =  new Select(Workforce.select_Qualification());
    oselect.selectByVisibleText(qali);
	
Log.info( " qualification is added Successfully" );
	} catch (Exception e) {
		Log.error("qualification does not add");
		throw(e);
					}

//Enetr Email
try {
	String email= ExcelUtils.getCellData(iTestCaseRow, Columndetails.Col_EmailId);
	System.out.println ("Email is :" + email);
   Workforce.Enetr_Eamil().sendKeys(email);
	
Log.info( "Email enter Successfully" );
	} catch (Exception e) {
		Log.error("Email does not enetr");
		throw(e);
					}
	 

//Enetr Phone
try {
	String phn= ExcelUtils.getCellData(iTestCaseRow, Columndetails.Col_PhoneNumber);
	System.out.println ("Email is :" + phn);
 Workforce.Enetr_Phone().sendKeys(phn);
	
Log.info( "Phone enter Successfully" );
	} catch (Exception e) {
		Log.error("Phone does not enetr");
		throw(e);
					}

//Enetr Correspondence Address
try {
	String CA= ExcelUtils.getCellData(iTestCaseRow, Columndetails.Col_CorrespondenceAddress);
	System.out.println ("CA is :" + CA);
 Workforce.Enetr_Corrsadd().sendKeys(CA);
	
Log.info( "CA Address enter Successfully" );
	} catch (Exception e) {
		Log.error("CA does not enetr");
	throw(e);
					}
 

//Enetr permanent_address 
try {
	String PA= ExcelUtils.getCellData(iTestCaseRow, Columndetails.Col_PermanentAddress);
	System.out.println ("PA is :" + PA);
Workforce.Enetr_Peradd().sendKeys(PA);
	
Log.info( "PA Address enter Successfully" );
	} catch (Exception e) {
		Log.error("PA does not enetr");
		throw(e);
					}

//Upload image

try {
	String profile= ExcelUtils.getCellData(iTestCaseRow, Columndetails.Col_ProfilePicture);
    System.out.println("Image Path is:" + profile);

   Workforce.browse_image().sendKeys(profile);
   Log.info( "Image uploaded Successfully" );
} catch (Exception e) {
	Log.error("Image Not Uploaded");
throw(e);
				}

//Add Basic Salary 

try {
	String basic= ExcelUtils.getCellData(iTestCaseRow, Columndetails.Col_BasicSalary);
    System.out.println("Image Path is:" + basic);

    Workforce.enetr_basic_salary().sendKeys(basic);
   Log.info( " Salary add Successfully" );
}   catch (Exception e) {
	Log.error("Salary does not add");
	throw(e);
				}

//Employee Save 

try {

Workforce.employee_save().click();
  Log.info( " Employee add Successfully" );
}   catch (Exception e) {
	Log.error("Employee does not add");
	throw(e);
}


//Qualification_Stream
try {
	String stream= ExcelUtils.getCellData(iTestCaseRow, Columndetails.Col_QualificationStream);
   System.out.println("Stream is:" + stream);

    Select oselect =  new Select(Workforce.select_Qualification_Stream());
   oselect.selectByVisibleText(stream);
		  
	  Log.info( "Qualification_Stream add Successfully" );
	}   catch (Exception e) {
		Log.error("Qualification_Stream does not add");
		throw(e);
				}
}
	}

