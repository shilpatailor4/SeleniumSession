package HRM_Module;

import org.apache.poi.ss.formula.functions.Value;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Reporter;
import org.testng.annotations.Test;
import PageObjects.Workforce;
import PageObjects.Employee_ApplicantLogin_Pom;
import PageObjects.Employee_Registration_Pom;
import PageObjects.HRM_Login;
import HRM_Module.HRM_Login_Action;
import Utility.Columndetails;
import Utility.ExcelUtils;
import Utility.Log;

public class Applicant_Screnning_Test {


	public static void Execute(int iTestCaseRow) throws Exception{

		//Enter Applicant Email
		try {
			String Aemail= ExcelUtils.getCellData(iTestCaseRow, Columndetails.Col_EmailId);
			System.out.println("Name :" + Aemail);
			Employee_ApplicantLogin_Pom.Applicant_Email().sendKeys(Aemail);
			Log.info( "Email Enter Successfully" );
		} catch (Exception e) {
			Log.error("Email does not Enter");
			throw(e);
		}

		//Enter Applicant Phone
		try {
			String Aphone= ExcelUtils.getCellData(iTestCaseRow, Columndetails.Col_PhoneNumber);
			System.out.println("Name :" + Aphone);
			Employee_ApplicantLogin_Pom.Applicant_Phone().sendKeys(Aphone);
			Log.info( "Phone Enter Successfully" );
		} catch (Exception e) {
			Log.error("Phone does not Enter");
			throw(e);
		}

		//Login by Applicant

		try {
			System.out.println("Click on Submit");
			Employee_ApplicantLogin_Pom.Applicant_Login().click();
			Log.info( "Login Successfully" );
		} catch (Exception e) {
			Log.error("Does not Login");
			throw(e);
		}

	}
}
